//Richard Thiart
unit Paywall_u;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.WinXCalendars, GlobalVariables_u, MainPage_u,
  Vcl.ExtCtrls, Vcl.ComCtrls, Vcl.Imaging.GIFImg, ComObj;

type
  TfrmPaywall = class(TForm)
    edtCardNumber: TEdit;
    btnAccept: TButton;
    cmbCardType: TComboBox;
    lblCardNumber: TLabel;
    lblExpirationDate: TLabel;
    calExpirationDate: TCalendarPicker;
    lblSecurityCode: TLabel;
    edtSecurityCode: TEdit;
    btnBypassPaywall: TButton;
    shpBackground: TShape;
    lblScroll: TLabel;
    shpCutoff: TShape;
    tmrTitelScroll: TTimer;
    redTerms: TRichEdit;
    btnLoadTOS: TButton;
    tmrLoadTOS: TTimer;
    imgPremiumGif: TImage;
    btnReadTOS: TButton;
    procedure btnAcceptClick(Sender: TObject);
    procedure btnBypassPaywallClick(Sender: TObject);
    procedure tmrTitelScrollTimer(Sender: TObject);                                                                                                                                                                                                                                                                                                                                                                                                                                                                              //Hierdie projek behoort aan Richard Thiart.
    procedure FormCreate(Sender: TObject);
    procedure tmrLoadTOSTimer(Sender: TObject);
    procedure btnLoadTOSClick(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure btnReadTOSClick(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
    var vSpeaker: OleVariant;
  public
    { Public declarations }
    var sCostRates, sTOS : String;
        iTosCount : Integer ;
  end;

var
  frmPaywall: TfrmPaywall;

implementation

uses
  login_u; //login_u is referenced here instead of under Interface > Uses to avoid a circular reference

{$R *.dfm}

procedure TfrmPaywall.btnAcceptClick(Sender: TObject);
var sCardNumber, sSecurityCode : String;
    iInt: Int64;        //iInt is never used. I only need TryStrToInt to test if sCardNumber is a number.
begin
sCardNumber := edtCardNumber.text;
sSecurityCode := edtSecurityCode.text;
                                            //Data validation:
if not ( (Length(sCardNumber) >= 15) and (Length(sCardNumber) <= 19) and TryStrToInt64(sCardNumber, iInt) ) then    //TryStrToInt() cannot handle integers this large so I have to use TryStrToInt64 and define iCard as Int64.
  begin
  Showmessage('Invalid Card number'+#13#10+'(Must be between 15 and 19 digits long)');
  edtCardNumber.setfocus;
  Exit
  end;

if Length(cmbCardType.text) < 1 then
  begin
  Showmessage('Select a Card Type');
  cmbCardType.setfocus;
  Exit;
  end;

if calExpirationDate.IsEmpty then
  begin
  Showmessage('Pick an expiration date');
  calExpirationDate.setfocus;
  Exit;
  end;

if (Length(sSecurityCode) <> 3) or not TryStrToInt64(sSecurityCode, iInt) then  // It needs to be TryStrToInt64 because the regular TryStrToInt cannot handle such large numbers
  begin
  Showmessage('Invalid security code'+#13#10+'(Must be a 3 digit number)');
  edtSecurityCode.setfocus;
  Exit;
  end;

Messagedlg('Sorry, we could not find your card :/',TMsgDlgType.mtInformation, [mbOK], 0);
btnBypassPaywall.visible := True;
end;

procedure TfrmPaywall.btnBypassPaywallClick(Sender: TObject);
var sPasswordInput : String;
begin
sPasswordInput := Inputbox('Bypass Paywall','Enter the Admin Password to bypass paywall.','');

if sPasswordInput <> sAdminPassword then  //Checks if the admin password is correct
  begin
  Showmessage('Incorrect Password');
  Exit;
  end;

sPassword := InputBox(sUsername,'Create a password','');    //Prompts the user to create a password

sUserType := 'Premium';

frmLogin.CreateAccount;  //Creates the textfile for a new account

if vSpeaker.Status.RunningState = 2 then   //Tests if the text to speach is reading or not
  begin
  vSpeaker.Speak('',2); //Stops reading Terms of service
  btnReadTOS.Caption := 'Read aloud';   //Resets the button
  end;

frmMainPage.show;
frmPaywall.close;
frmLogin.hide;     //Login_u needs to be under Uses for this line to work.
frmMainPage.FormShow(frmMainPage); //Forces the on show event of frmMainPage to run even if the form is already showing

Showmessage('Welcome! You now have full access to our PREMIUM Calculator service. All payments will be charged to your card automatically.'+#13#10#10+'(If you are an Admin or if you bypassed the Paywall screen you will be using fake money)');
end;

procedure TfrmPaywall.btnLoadTOSClick(Sender: TObject);
begin
redTerms.Clear ;      //Have to clear otherwise I get a range check error if i press the button twice
iTosCount := 1 ;      //Initialises the character count variable
tmrLoadTOS.Enabled := True ;
end;

procedure TfrmPaywall.btnReadTOSClick(Sender: TObject);
begin
if vSpeaker.Status.RunningState = 2 then   //Tests if the text to speach is reading or not
  begin
  vSpeaker.Speak('',2); //Stops reading
  btnReadTOS.Caption := 'Read aloud';   //Resets the button's caption
  end
else
  begin
  vSpeaker.Speak(sTos,1);  //Reads the terms of service
  btnReadTOS.Caption := 'Stop';  //Sets the button's caption to stop
  end;
end;

procedure TfrmPaywall.FormClose(Sender: TObject; var Action: TCloseAction);
begin
if vSpeaker.Status.RunningState = 2 then   //Tests if the text to speach is reading or not
  begin
  vSpeaker.Speak('',2); //Stops reading Terms of service
  btnReadTOS.Caption := 'Read aloud';   //Resets the button
  end;
end;

procedure TfrmPaywall.FormCreate(Sender: TObject);
var sTerms : String ;
begin
sTerms := 'TERMS OF SERVICE:'+#13+
        'The following will apply to you once you click ACCEPT on the right hand side:'+#13#13+
        '1. Zero sign up cost:'+#13+'You will be granted access to all premium features without paying a sign up fee. However, all premium features have their own usage cost.'+#13#13+
        '2. Free uses:'+#13+'Although you are a premium member, you still have access to the free uses that the basic calculator has to offer.'+#13#13+
        '3. PAYMENT:'+#13+
        'All payments will be charged to your card once you exit the program.'+#13+
        'The total cost of a single usage is calculated using the Cost Rate and the sum of Input Numbers. The following formula is used to calculate the cost of functions Plus, Minus, Multiply, Divide, Powers, Log, Div and Mod:'+#13+
        '(Input 1 + Input 2) � Rate.'+#13#13+
        'The trigonometry and number conversion functions only have one input and their formula for calculating cost is simply Input � Rate.'+#13+
        'Your data may be collected and seen by admins.'+#13+
        'Admins may charge you fees if they feel like it.';

sCostRates := 'COST RATES:'+#13+
              'Plus '+FloatToStr(PlusCost)+#13+
              'Minus '+FloatToStr(MinusCost)+#13+
              'Multiply '+FloatToStr(MultiplyCost)+#13+
              'Divide '+FloatToStr(DivideCost)+#13+
              'Exponent '+FloatToStr(ExponentCost)+#13+
              'Log '+FloatToStr(LogCost)+#13+
              'Div '+FloatToStr(DivCost)+#13+
              'Mod '+FloatToStr(ModCost)+#13+
              'Sin '+FloatToStr(SinCost)+#13+
              'Cos '+FloatToStr(CosCost)+#13+
              'Tan '+FloatToStr(TanCost)+#13+
              'Number Conversions '+FloatToStr(ConvertCost) ;

sTOS := sTerms+#13#10+sCostRates ;

vSpeaker := CreateOleObject('SAPI.SpVoice'); //Initialises the text to speech voice that reads the Terms Of Service
vSpeaker.Rate := 6;
end;

procedure TfrmPaywall.FormShow(Sender: TObject);
begin
tmrTitelScroll.Enabled := True;     //Begins scrolling the text "Enter your credit card information"
(imgPremiumGif.Picture.Graphic as TGIFImage).Animate := True; //Begins the gif animation
end;

procedure TfrmPaywall.tmrLoadTOSTimer(Sender: TObject);
begin
redTerms.SelStart := Length(redTerms.Text) ;     //Places the curser at the end of the rich edit
redTerms.SelText := sTOS[iTosCount] ;     //Prints a letter
iTosCount := iTosCount +1 ;
if iTosCount = Length(sTOS) + 1 then      //Checks if the entire TOS is already printed and stops the timer if yes
  tmrLoadTOS.Enabled := False ;
end;

procedure TfrmPaywall.tmrTitelScrollTimer(Sender: TObject);
begin
if lblScroll.left > -20 then
  lblScroll.Left := lblScroll.left -20   //Makes the text scroll to the left like an LED scrolling marquee
else
  begin
  lblScroll.Left := 500;       //Resets the text back to its starting position
  Refresh;
  end;
end;

end.
