object frmLogin: TfrmLogin
  Left = 0
  Top = 166
  Caption = 'Login'
  ClientHeight = 364
  ClientWidth = 532
  Color = clHotLight
  Font.Charset = ANSI_CHARSET
  Font.Color = clBlack
  Font.Height = -13
  Font.Name = 'Consolas'
  Font.Style = [fsBold]
  Position = poDesigned
  OnCreate = FormCreate
  TextHeight = 15
  object lblUsername: TLabel
    Left = 132
    Top = 134
    Width = 90
    Height = 22
    Caption = 'Username:'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWhite
    Font.Height = -19
    Font.Name = 'Consolas'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object lblAdminPassword: TLabel
    Left = 72
    Top = 167
    Width = 150
    Height = 22
    Caption = 'Admin Password:'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWhite
    Font.Height = -19
    Font.Name = 'Consolas'
    Font.Style = [fsBold]
    ParentFont = False
    Visible = False
  end
  object lblMainTitle: TLabel
    Left = 32
    Top = 40
    Width = 460
    Height = 43
    Caption = 'Capitalistic Calculator'
    Font.Charset = ANSI_CHARSET
    Font.Color = clLime
    Font.Height = -37
    Font.Name = 'Consolas'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object lblTaken: TLabel
    Left = 399
    Top = 139
    Width = 7
    Height = 15
  end
  object lblSelectType: TLabel
    Left = 32
    Top = 197
    Width = 190
    Height = 22
    Caption = 'Select a user type:'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWhite
    Font.Height = -19
    Font.Name = 'Consolas'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object edtUsername: TEdit
    Left = 232
    Top = 136
    Width = 161
    Height = 23
    Hint = 'This project was created by Richard Thiart'
    ParentCustomHint = False
    MaxLength = -1
    ParentShowHint = False
    ShowHint = False
    TabOrder = 0
    OnChange = edtUsernameChange
  end
  object cmbUserType: TComboBox
    Left = 232
    Top = 196
    Width = 161
    Height = 23
    Style = csDropDownList
    TabOrder = 1
    OnChange = cmbUserTypeChange
    Items.Strings = (
      'Regular user'
      'Admin')
  end
  object edtAdminPassword: TEdit
    Left = 232
    Top = 166
    Width = 161
    Height = 23
    ParentShowHint = False
    ShowHint = True
    TabOrder = 2
    Visible = False
  end
  object btnLogIn: TButton
    Left = 232
    Top = 225
    Width = 97
    Height = 25
    Caption = 'Log in'
    TabOrder = 3
    Visible = False
    OnClick = btnLogInClick
  end
  object chxPremium: TCheckBox
    Left = 232
    Top = 264
    Width = 97
    Height = 17
    Caption = 'Premium'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWhite
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 4
    Visible = False
    OnClick = chxPremiumClick
  end
end
