object frmMainPage: TfrmMainPage
  Left = 347
  Top = 41
  Caption = 'Capitalistic Calculator'
  ClientHeight = 902
  ClientWidth = 981
  Color = clBtnFace
  Font.Charset = ANSI_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Consolas'
  Font.Style = []
  Position = poDesigned
  Scaled = False
  ShowInTaskBar = True
  OnClose = FormClose
  OnCreate = FormCreate
  OnResize = FormResize
  OnShow = FormShow
  TextHeight = 14
  object scrbxForm: TScrollBox
    Left = 0
    Top = 5
    Width = 977
    Height = 892
    Margins.Left = 0
    Margins.Top = 0
    Margins.Right = 0
    Margins.Bottom = 0
    HorzScrollBar.Color = clBlack
    HorzScrollBar.ParentColor = False
    HorzScrollBar.Range = 2000
    VertScrollBar.Color = clBlack
    VertScrollBar.ParentColor = False
    VertScrollBar.Range = 890
    AutoScroll = False
    TabOrder = 0
    UseWheelForScrolling = True
    object shpWatermark: TShape
      Left = 861
      Top = -2
      Width = 211
      Height = 67
      Cursor = crHourGlass
      Hint = 'This project was created by Richard Thiart'
      Brush.Style = bsClear
      ParentShowHint = False
      Pen.Style = psClear
      Shape = stRoundRect
      ShowHint = True
      OnContextPopup = shpWatermarkContextPopup
    end
    object pgcMain: TPageControl
      Left = 0
      Top = 16
      Width = 964
      Height = 865
      ActivePage = tabCalculator
      TabOrder = 0
      object tabCalculator: TTabSheet
        Caption = 'Calculator'
        object shpCalculatorBackground: TShape
          Left = -134
          Top = -116
          Width = 1090
          Height = 1000
          Pen.Style = psClear
        end
        object pnlAdvancedCalculator: TPanel
          Left = 197
          Top = 8
          Width = 437
          Height = 386
          Caption = 'Advanced Calculator '
          Color = clGray
          Font.Charset = ANSI_CHARSET
          Font.Color = clBlack
          Font.Height = -13
          Font.Name = 'Tahoma'
          Font.Style = [fsBold, fsItalic]
          ParentBackground = False
          ParentFont = False
          TabOrder = 0
          VerticalAlignment = taAlignTop
          object lblConversionsTitle: TLabel
            Left = 25
            Top = 183
            Width = 147
            Height = 16
            Caption = 'Number base conversions'
            Font.Charset = ANSI_CHARSET
            Font.Color = clBlack
            Font.Height = -13
            Font.Name = 'Tahoma'
            Font.Style = [fsUnderline]
            ParentFont = False
          end
          object lblDegrees: TLabel
            Left = 77
            Top = 142
            Width = 6
            Height = 20
            Caption = #176
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -15
            Font.Name = 'Segoe UI'
            Font.Style = [fsBold]
            ParentFont = False
          end
          object lblLog: TLabel
            Left = 26
            Top = 43
            Width = 30
            Height = 23
            Caption = 'Log'
            Font.Charset = ANSI_CHARSET
            Font.Color = clBlack
            Font.Height = -19
            Font.Name = 'Tahoma'
            Font.Style = []
            ParentFont = False
            Visible = False
          end
          object lblBracket: TLabel
            Left = 87
            Top = 43
            Width = 8
            Height = 25
            Caption = '('
            Font.Charset = ANSI_CHARSET
            Font.Color = clBlack
            Font.Height = -21
            Font.Name = 'Tahoma'
            Font.Style = []
            ParentFont = False
            Visible = False
          end
          object edtTrig: TEdit
            Left = 25
            Top = 149
            Width = 53
            Height = 23
            Enabled = False
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe UI'
            Font.Style = []
            MaxLength = 25
            ParentFont = False
            TabOrder = 10
            Text = '90'
          end
          object edtExp1: TEdit
            Left = 73
            Top = 47
            Width = 68
            Height = 23
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe UI'
            Font.Style = []
            MaxLength = 25
            ParentFont = False
            ParentShowHint = False
            ShowHint = True
            TabOrder = 0
            TextHint = 'Base'
          end
          object edtExp2: TEdit
            Left = 130
            Top = 31
            Width = 32
            Height = 23
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe UI'
            Font.Style = []
            MaxLength = 25
            NumbersOnly = True
            ParentFont = False
            TabOrder = 1
            TextHint = 'Exp'
          end
          object btnCalcExponents: TButton
            Left = 169
            Top = 43
            Width = 33
            Height = 25
            Caption = '='
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -19
            Font.Name = 'Tahoma'
            Font.Style = []
            ParentFont = False
            TabOrder = 2
            OnClick = btnCalcExponentsClick
          end
          object redAnswers: TRichEdit
            Left = 224
            Top = 24
            Width = 201
            Height = 345
            Enabled = False
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -16
            Font.Name = 'Segoe UI'
            Font.Style = []
            Lines.Strings = (
              'Answers:')
            ParentFont = False
            ReadOnly = True
            ScrollBars = ssBoth
            TabOrder = 3
          end
          object btnDiv: TButton
            Left = 90
            Top = 80
            Width = 47
            Height = 25
            Caption = 'DIV'
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe UI'
            Font.Style = []
            ParentFont = False
            TabOrder = 4
            OnClick = btnDivClick
          end
          object sedDiv1: TSpinEdit
            Left = 25
            Top = 80
            Width = 59
            Height = 24
            Enabled = False
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe UI'
            Font.Style = []
            MaxValue = 100000000
            MinValue = -100000000
            ParentFont = False
            TabOrder = 5
            Value = 11
          end
          object sedDiv2: TSpinEdit
            Left = 143
            Top = 80
            Width = 59
            Height = 24
            Enabled = False
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe UI'
            Font.Style = []
            MaxValue = 100000000
            MinValue = -100000000
            ParentFont = False
            TabOrder = 6
            Value = 2
          end
          object sedMod1: TSpinEdit
            Left = 25
            Top = 111
            Width = 59
            Height = 24
            Enabled = False
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe UI'
            Font.Style = []
            MaxValue = 100000000
            MinValue = -100000000
            ParentFont = False
            TabOrder = 7
            Value = 11
          end
          object btnMod: TButton
            Left = 90
            Top = 111
            Width = 47
            Height = 25
            Caption = 'MOD'
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe UI'
            Font.Style = []
            ParentFont = False
            TabOrder = 8
            OnClick = btnModClick
          end
          object sedMod2: TSpinEdit
            Left = 143
            Top = 111
            Width = 59
            Height = 24
            Enabled = False
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe UI'
            Font.Style = []
            MaxValue = 100000000
            MinValue = -100000000
            ParentFont = False
            TabOrder = 9
            Value = 2
          end
          object btnSine: TButton
            Left = 95
            Top = 148
            Width = 32
            Height = 25
            Caption = 'sin'
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe UI'
            Font.Style = []
            ParentFont = False
            TabOrder = 11
            OnClick = btnSineClick
          end
          object btnCosine: TButton
            Left = 133
            Top = 148
            Width = 32
            Height = 25
            Caption = 'cos'
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe UI'
            Font.Style = []
            ParentFont = False
            TabOrder = 12
            OnClick = btnCosineClick
          end
          object btnTangent: TButton
            Left = 171
            Top = 148
            Width = 32
            Height = 25
            Caption = 'tan'
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe UI'
            Font.Style = []
            ParentFont = False
            TabOrder = 13
            OnClick = btnTangentClick
          end
          object edtConversions: TEdit
            Left = 25
            Top = 205
            Width = 161
            Height = 24
            Font.Charset = ANSI_CHARSET
            Font.Color = clBlack
            Font.Height = -13
            Font.Name = 'Tahoma'
            Font.Style = []
            MaxLength = 25
            ParentFont = False
            TabOrder = 14
          end
          object btnBinaryToDecimal: TButton
            Left = 25
            Top = 240
            Width = 161
            Height = 25
            Caption = 'Binary to Decimal'
            Font.Charset = ANSI_CHARSET
            Font.Color = clBlack
            Font.Height = -13
            Font.Name = 'Tahoma'
            Font.Style = []
            ParentFont = False
            TabOrder = 15
            OnClick = btnBinaryToDecimalClick
          end
          object btnDecimalToBinary: TButton
            Left = 25
            Top = 271
            Width = 161
            Height = 25
            Caption = 'Decimal to Binary'
            Font.Charset = ANSI_CHARSET
            Font.Color = clBlack
            Font.Height = -13
            Font.Name = 'Tahoma'
            Font.Style = []
            ParentFont = False
            TabOrder = 16
            OnClick = btnDecimalToBinaryClick
          end
          object btnHexadecimalToDecimal: TButton
            Left = 25
            Top = 309
            Width = 160
            Height = 25
            Caption = 'Hexadecimal to Decimal'
            Font.Charset = ANSI_CHARSET
            Font.Color = clBlack
            Font.Height = -13
            Font.Name = 'Tahoma'
            Font.Style = []
            ParentFont = False
            TabOrder = 17
            OnClick = btnHexadecimalToDecimalClick
          end
          object btnDecimalToHexadecimal: TButton
            Left = 25
            Top = 340
            Width = 161
            Height = 25
            Caption = 'Decimal to Hexadecimal'
            Font.Charset = ANSI_CHARSET
            Font.Color = clBlack
            Font.Height = -13
            Font.Name = 'Tahoma'
            Font.Style = []
            ParentFont = False
            TabOrder = 18
            OnClick = btnDecimalToHexadecimalClick
          end
          object btnInvert: TButton
            Left = 12
            Top = 14
            Width = 30
            Height = 30
            Hint = 'Invert Calculation'
            Margins.Top = 0
            Caption = #8617#65038
            Font.Charset = ANSI_CHARSET
            Font.Color = clBlack
            Font.Height = -27
            Font.Name = 'Consolas'
            Font.Style = []
            ParentFont = False
            ParentShowHint = False
            ShowHint = True
            TabOrder = 19
            OnClick = btnInvertClick
          end
        end
        object pnlBasicCalculator: TPanel
          Left = 8
          Top = 121
          Width = 183
          Height = 273
          Caption = 'Basic Calculator'
          Color = clLightgreen
          ParentBackground = False
          TabOrder = 1
          VerticalAlignment = taAlignTop
          object btn1: TButton
            Left = 16
            Top = 166
            Width = 33
            Height = 33
            Caption = '1'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -24
            Font.Name = 'Monoid'
            Font.Style = []
            ParentFont = False
            TabOrder = 0
            OnClick = btn1Click
          end
          object btn2: TButton
            Left = 55
            Top = 166
            Width = 33
            Height = 33
            Caption = '2'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -24
            Font.Name = 'Monoid'
            Font.Style = []
            ParentFont = False
            TabOrder = 1
            OnClick = btn2Click
          end
          object btn3: TButton
            Left = 94
            Top = 166
            Width = 33
            Height = 33
            Caption = '3'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -24
            Font.Name = 'Monoid'
            Font.Style = []
            ParentFont = False
            TabOrder = 2
            OnClick = btn3Click
          end
          object btn4: TButton
            Left = 16
            Top = 127
            Width = 33
            Height = 33
            Caption = '4'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -24
            Font.Name = 'Monoid'
            Font.Style = []
            ParentFont = False
            TabOrder = 3
            OnClick = btn4Click
          end
          object btn5: TButton
            Left = 55
            Top = 127
            Width = 33
            Height = 33
            Caption = '5'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -24
            Font.Name = 'Monoid'
            Font.Style = []
            ParentFont = False
            TabOrder = 4
            OnClick = btn5Click
          end
          object btn6: TButton
            Left = 94
            Top = 127
            Width = 33
            Height = 33
            Caption = '6'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -24
            Font.Name = 'Monoid'
            Font.Style = []
            ParentFont = False
            TabOrder = 5
            OnClick = btn6Click
          end
          object btn7: TButton
            Left = 16
            Top = 88
            Width = 33
            Height = 33
            Caption = '7'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -24
            Font.Name = 'Monoid'
            Font.Style = []
            ParentFont = False
            TabOrder = 6
            OnClick = btn7Click
          end
          object btn8: TButton
            Left = 55
            Top = 88
            Width = 33
            Height = 33
            Caption = '8'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -24
            Font.Name = 'Monoid'
            Font.Style = []
            ParentFont = False
            TabOrder = 7
            OnClick = btn8Click
          end
          object btn9: TButton
            Left = 94
            Top = 88
            Width = 33
            Height = 33
            Caption = '9'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -24
            Font.Name = 'Monoid'
            Font.Style = []
            ParentFont = False
            TabOrder = 8
            OnClick = btn9Click
          end
          object btn0: TButton
            Left = 55
            Top = 205
            Width = 33
            Height = 33
            Caption = '0'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -24
            Font.Name = 'Monoid'
            Font.Style = []
            ParentFont = False
            TabOrder = 9
            OnClick = btn0Click
          end
          object btnEquals: TButton
            Left = 94
            Top = 205
            Width = 33
            Height = 33
            Caption = '='
            Enabled = False
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -24
            Font.Name = 'Monoid'
            Font.Style = []
            ParentFont = False
            TabOrder = 10
            OnClick = btnEqualsClick
          end
          object btnPlus: TButton
            Left = 133
            Top = 88
            Width = 33
            Height = 33
            Caption = '+'
            Enabled = False
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -24
            Font.Name = 'Monoid'
            Font.Style = []
            ParentFont = False
            TabOrder = 11
            OnClick = btnPlusClick
          end
          object btnMinus: TButton
            Left = 133
            Top = 127
            Width = 33
            Height = 33
            Caption = '-'
            Enabled = False
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -24
            Font.Name = 'Monoid'
            Font.Style = []
            ParentFont = False
            TabOrder = 12
            OnClick = btnMinusClick
          end
          object btnMultiply: TButton
            Left = 133
            Top = 166
            Width = 33
            Height = 33
            Caption = #215
            Enabled = False
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -24
            Font.Name = 'Monoid'
            Font.Style = []
            ParentFont = False
            TabOrder = 13
            OnClick = btnMultiplyClick
          end
          object btnDivide: TButton
            Left = 133
            Top = 205
            Width = 33
            Height = 33
            Caption = #247
            Enabled = False
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -24
            Font.Name = 'Monoid'
            Font.Style = []
            ParentFont = False
            TabOrder = 14
            OnClick = btnDivideClick
          end
          object btnBasicClear: TButton
            Left = 16
            Top = 205
            Width = 33
            Height = 33
            Caption = 'CE'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -19
            Font.Name = 'Monoid'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 15
            OnClick = btnBasicClearClick
          end
          object memBasicCalculator: TMemo
            Left = 16
            Top = 24
            Width = 150
            Height = 49
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -16
            Font.Name = 'Consolas'
            Font.Style = [fsBold]
            MaxLength = 1500000
            ParentFont = False
            ReadOnly = True
            TabOrder = 16
            StyleElements = [seFont, seClient]
          end
        end
        object pnlInvest: TPanel
          Left = 3
          Top = 400
          Width = 913
          Height = 425
          Color = clBlack
          Font.Charset = ANSI_CHARSET
          Font.Color = clBlue
          Font.Height = -16
          Font.Name = 'Consolas'
          Font.Style = [fsBold]
          ParentBackground = False
          ParentFont = False
          TabOrder = 2
          VerticalAlignment = taAlignTop
          object lblInterestRateTitle: TLabel
            Left = 795
            Top = 65
            Width = 90
            Height = 19
            Caption = 'Growth rate:'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWhite
            Font.Height = -16
            Font.Name = 'Tahoma'
            Font.Style = []
            ParentFont = False
          end
          object lblPercent: TLabel
            Left = 854
            Top = 86
            Width = 19
            Height = 23
            Caption = '%'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWhite
            Font.Height = -19
            Font.Name = 'Tahoma'
            Font.Style = []
            ParentFont = False
          end
          object lblInvestAmount: TLabel
            Left = 795
            Top = 309
            Width = 63
            Height = 19
            Caption = 'Amount:'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWhite
            Font.Height = -16
            Font.Name = 'Tahoma'
            Font.Style = []
            ParentFont = False
          end
          object lblVolatility: TLabel
            Left = 795
            Top = 170
            Width = 67
            Height = 19
            Caption = 'Volatility:'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWhite
            Font.Height = -16
            Font.Name = 'Tahoma'
            Font.Style = []
            ParentFont = False
          end
          object lblCrashed: TLabel
            Left = 795
            Top = 361
            Width = 110
            Height = 49
            AutoSize = False
            WordWrap = True
          end
          object lblYears: TLabel
            Left = 795
            Top = 120
            Width = 45
            Height = 19
            Caption = 'Years:'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWhite
            Font.Height = -16
            Font.Name = 'Tahoma'
            Font.Style = []
            ParentFont = False
          end
          object btnInvest: TButton
            Left = 795
            Top = 26
            Width = 81
            Height = 33
            Hint = 'Invest your total spent'
            Caption = 'Invest!'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -16
            Font.Name = 'Tahoma'
            Font.Style = [fsBold]
            ParentFont = False
            ParentShowHint = False
            ShowHint = True
            TabOrder = 0
            OnClick = btnInvestClick
          end
          object edtGrowthRate: TEdit
            Left = 795
            Top = 86
            Width = 57
            Height = 30
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -19
            Font.Name = 'Consolas'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 1
            Text = '10'
          end
          object btnInvestCalculate: TButton
            Left = 795
            Top = 270
            Width = 81
            Height = 33
            Hint = 'Invest a custom amount'
            Caption = 'Calculate'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -16
            Font.Name = 'Tahoma'
            Font.Style = []
            ParentFont = False
            ParentShowHint = False
            ShowHint = True
            TabOrder = 2
            OnClick = btnInvestCalculateClick
          end
          object edtInvestAmount: TEdit
            Left = 795
            Top = 328
            Width = 97
            Height = 27
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -16
            Font.Name = 'Tahoma'
            Font.Style = []
            ParentFont = False
            TabOrder = 3
          end
          object chartInvest: TChart
            Left = 21
            Top = 15
            Width = 758
            Height = 394
            Cursor = crCross
            AllowPanning = pmNone
            Gradient.Colors = <
              item
              end
              item
                Color = clGreen
                Offset = 0.401197604790419200
              end
              item
                Color = 51738
                Offset = 1.000000000000000000
              end>
            Gradient.EndColor = 51738
            Gradient.MidColor = clGreen
            Gradient.StartColor = clBlack
            Legend.Visible = False
            MarginBottom = 0
            MarginLeft = 4
            MarginRight = 4
            SubTitle.Margins.Left = 6
            SubTitle.Margins.Top = 0
            SubTitle.Margins.Right = 0
            SubTitle.Margins.Bottom = 0
            SubTitle.Visible = False
            Title.Color = clLime
            Title.Font.Charset = ANSI_CHARSET
            Title.Font.Height = -19
            Title.Font.Name = 'Consolas'
            Title.Font.Style = [fsBold]
            Title.Frame.Width = 0
            Title.Margins.Left = 0
            Title.Margins.Top = 0
            Title.Margins.Right = 0
            Title.Margins.Bottom = 0
            Title.Margins.Units = maPixels
            Title.Text.Strings = (
              'Investment Calculator')
            BottomAxis.Grid.Color = 1287700672
            BottomAxis.Increment = 1.000000000000000000
            BottomAxis.LabelsFormat.Font.Height = -13
            BottomAxis.LabelsFormat.Font.Name = 'Consolas'
            BottomAxis.LabelsFormat.Font.Style = [fsBold]
            BottomAxis.Title.Caption = 'Years'
            BottomAxis.Title.Font.Color = clBlue
            BottomAxis.Title.Font.Height = -13
            BottomAxis.Title.Font.Name = 'Consolas'
            BottomAxis.Title.Font.Style = [fsBold]
            BottomAxis.Title.Color = clBlack
            DepthAxis.Grid.Visible = False
            DepthTopAxis.Grid.Visible = False
            Emboss.HorizSize = 16
            Emboss.VertSize = 16
            LeftAxis.Grid.Color = 1472250048
            LeftAxis.LabelsFormat.Font.Charset = ANSI_CHARSET
            LeftAxis.LabelsFormat.Font.Height = -13
            LeftAxis.LabelsFormat.Font.Name = 'Consolas'
            LeftAxis.LabelsFormat.Font.Style = [fsBold]
            LeftAxis.Title.Caption = 'Value (Rand)'
            LeftAxis.Title.Font.Charset = ANSI_CHARSET
            LeftAxis.Title.Font.Color = clBlue
            LeftAxis.Title.Font.Height = -13
            LeftAxis.Title.Font.Name = 'Consolas'
            LeftAxis.Title.Font.Style = [fsBold]
            Panning.MouseWheel = pmwNone
            RightAxis.LabelsFormat.Font.Color = clWhite
            Shadow.Color = clRed
            Shadow.Transparency = 49
            Shadow.Visible = False
            TopAxis.Grid.Visible = False
            View3D = False
            Zoom.Allow = False
            ZoomWheel = pmwNormal
            Color = clGray
            TabOrder = 4
            DefaultCanvas = 'TGDIPlusCanvas'
            ColorPaletteIndex = 13
            object Data: TLineSeries
              HoverElement = [heCurrent]
              Marks.Visible = True
              Marks.DrawEvery = 5000
              Marks.Symbol.Transparency = 12
              Marks.Tail.Visible = True
              SeriesColor = clWhite
              Shadow.Color = 12500670
              Title = 'Data'
              Brush.BackColor = clDefault
              DrawStyle = dsAll
              LinePen.Width = 4
              Pointer.InflateMargins = True
              Pointer.Style = psRectangle
              XValues.Name = 'X'
              XValues.Order = loAscending
              YValues.Name = 'Y'
              YValues.Order = loNone
            end
          end
          object sedVolatility: TSpinEdit
            Left = 795
            Top = 190
            Width = 57
            Height = 32
            Font.Charset = ANSI_CHARSET
            Font.Color = clBlack
            Font.Height = -19
            Font.Name = 'Consolas'
            Font.Style = [fsBold]
            MaxValue = 150
            MinValue = 0
            ParentFont = False
            TabOrder = 5
            Value = 15
          end
          object sedYears: TSpinEdit
            Left = 795
            Top = 138
            Width = 57
            Height = 32
            Font.Charset = ANSI_CHARSET
            Font.Color = clBlack
            Font.Height = -19
            Font.Name = 'Consolas'
            Font.Style = [fsBold]
            MaxLength = 3
            MaxValue = 500
            MinValue = 1
            ParentFont = False
            TabOrder = 6
            Value = 50
          end
          object btnInvestInfo: TButton
            Left = 858
            Top = 192
            Width = 27
            Height = 27
            Caption = '?'
            TabOrder = 7
            OnClick = btnInvestInfoClick
          end
        end
        object redCost: TRichEdit
          Left = 640
          Top = 8
          Width = 276
          Height = 358
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Consolas'
          Font.Style = []
          Lines.Strings = (
            'Username:'
            'User type:'
            ''
            'Spending'
            'Amount:       Tag      (Rate'#215'Inputs)'
            '------------------------------------'
            '------------------------------------'
            'Total:'
            'R0')
          ParentFont = False
          PlainText = True
          ReadOnly = True
          ScrollBars = ssBoth
          TabOrder = 3
          Visible = False
        end
        object redFreeClicksLeft: TRichEdit
          Left = 8
          Top = 8
          Width = 183
          Height = 104
          TabStop = False
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Segoe UI'
          Font.Style = []
          ParentFont = False
          ReadOnly = True
          TabOrder = 4
        end
        object edtBalance: TEdit
          Left = 640
          Top = 372
          Width = 276
          Height = 22
          TabOrder = 5
          Text = 'Outstanding Balance: R0'
          Visible = False
        end
        object btnBalanceInfo: TButton
          Left = 923
          Top = 368
          Width = 27
          Height = 27
          Caption = '?'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -16
          Font.Name = 'Consolas'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 6
          OnClick = btnBalanceInfoClick
        end
        object btnFreeInfo: TButton
          Left = 164
          Top = 88
          Width = 27
          Height = 27
          Caption = '?'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -16
          Font.Name = 'Consolas'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 7
          OnClick = btnFreeInfoClick
        end
      end
      object tabSettings: TTabSheet
        Caption = 'Settings'
        Font.Charset = ANSI_CHARSET
        Font.Color = clWindowText
        Font.Height = -16
        Font.Name = 'Consolas'
        Font.Style = []
        ImageIndex = 1
        ParentFont = False
        object shpBackgroundColor: TShape
          Left = 207
          Top = 16
          Width = 74
          Height = 169
          Pen.Style = psDash
        end
        object lblCollectDataSetting: TLabel
          Left = 16
          Top = 318
          Width = 135
          Height = 19
          Caption = 'Collect my data'
        end
        object lblUnsaved: TLabel
          Left = 599
          Top = 408
          Width = 9
          Height = 19
        end
        object lblCostRatesLabel: TLabel
          Left = 440
          Top = 3
          Width = 90
          Height = 19
          Caption = 'Cost Rates'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -16
          Font.Name = 'Consolas'
          Font.Style = [fsUnderline]
          ParentFont = False
        end
        object rgpBackgroundColour: TRadioGroup
          Left = 16
          Top = 3
          Width = 185
          Height = 182
          Caption = 'Background colour'
          ItemIndex = 0
          Items.Strings = (
            'White'
            'Black'
            'Red'
            'Green'
            'Blue'
            'All of the above')
          TabOrder = 0
          OnClick = rgpBackgroundColourClick
        end
        object tsCollectData: TToggleSwitch
          Left = 184
          Top = 316
          Width = 83
          Height = 21
          State = tssOn
          StateCaptions.CaptionOn = 'Yes'
          StateCaptions.CaptionOff = 'No'
          TabOrder = 1
          OnClick = tsCollectDataClick
        end
        object lstCostRates: TListBox
          Left = 440
          Top = 28
          Width = 313
          Height = 341
          ItemHeight = 19
          TabOrder = 2
        end
        object btnChangeCostRate: TButton
          Left = 440
          Top = 375
          Width = 153
          Height = 25
          Caption = 'Change price'
          TabOrder = 3
          OnClick = btnChangeCostRateClick
        end
        object btnSaveCostRates: TButton
          Left = 600
          Top = 375
          Width = 153
          Height = 25
          Caption = 'Save'
          TabOrder = 4
          OnClick = btnSaveCostRatesClick
        end
        object btnUndoChanges: TButton
          Left = 544
          Top = 406
          Width = 49
          Height = 25
          Caption = 'Undo'
          Enabled = False
          TabOrder = 5
          OnClick = btnUndoChangesClick
        end
        object btnChangePassword: TButton
          Left = 16
          Top = 208
          Width = 161
          Height = 25
          Caption = 'Change Password'
          TabOrder = 6
          OnClick = btnChangePasswordClick
        end
        object btnDeleteAccount: TButton
          Left = 16
          Top = 248
          Width = 161
          Height = 25
          Caption = 'Delete account'
          TabOrder = 7
          OnClick = btnDeleteAccountClick
        end
      end
      object tabAdmin: TTabSheet
        Caption = 'Admin'
        ImageIndex = 2
        object lblAdminPassword: TLabel
          Left = 16
          Top = 14
          Width = 135
          Height = 19
          Caption = 'Admin Password:'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -16
          Font.Name = 'Consolas'
          Font.Style = []
          ParentFont = False
        end
        object lblUsers: TLabel
          Left = 296
          Top = 14
          Width = 45
          Height = 19
          Caption = 'Users'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -16
          Font.Name = 'Consolas'
          Font.Style = [fsUnderline]
          ParentFont = False
        end
        object lblUserData: TLabel
          Left = 648
          Top = 14
          Width = 81
          Height = 19
          Caption = 'User data'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -16
          Font.Name = 'Consolas'
          Font.Style = [fsUnderline]
          ParentFont = False
        end
        object edtAdminPassword: TEdit
          Left = 16
          Top = 39
          Width = 177
          Height = 22
          TabOrder = 0
          OnChange = edtAdminPasswordChange
        end
        object lstUsers: TListBox
          Left = 296
          Top = 39
          Width = 346
          Height = 731
          ItemHeight = 14
          TabOrder = 1
          OnClick = lstUsersClick
        end
        object btnChargeUser: TButton
          Left = 16
          Top = 167
          Width = 97
          Height = 25
          Caption = 'Add Fee'
          TabOrder = 2
          OnClick = btnChargeUserClick
        end
        object redUserInfo: TRichEdit
          Left = 648
          Top = 39
          Width = 276
          Height = 731
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Consolas'
          Font.Style = []
          ParentFont = False
          PlainText = True
          ReadOnly = True
          ScrollBars = ssBoth
          TabOrder = 3
        end
        object btnLoadUsers: TButton
          Left = 16
          Top = 94
          Width = 97
          Height = 25
          Caption = 'Load Users'
          TabOrder = 4
          OnClick = btnLoadUsersClick
        end
      end
    end
  end
  object tmrAdvertisePremium: TTimer
    Enabled = False
    OnTimer = tmrAdvertisePremiumTimer
    Left = 188
    Top = 464
  end
  object tmrTurnDataCollectionBackOn: TTimer
    Enabled = False
    OnTimer = tmrTurnDataCollectionBackOnTimer
    Left = 148
    Top = 674
  end
  object tmrRainbowBackground: TTimer
    Enabled = False
    OnTimer = tmrRainbowBackgroundTimer
    Left = 196
    Top = 562
  end
end
