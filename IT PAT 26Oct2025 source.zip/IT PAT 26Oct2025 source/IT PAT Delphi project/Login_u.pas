//Richard Thiart
unit Login_u;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Paywall_u, MainPage_u, GlobalVariables_u,System.Types,
  System.IOUtils, Vcl.ExtCtrls;

type
  TfrmLogin = class(TForm)
    edtUsername: TEdit;
    lblUsername: TLabel;
    cmbUserType: TComboBox;
    edtAdminPassword: TEdit;
    btnLogIn: TButton;
    lblAdminPassword: TLabel;
    chxPremium: TCheckBox;
    lblMainTitle: TLabel;
    lblTaken: TLabel;
    lblSelectType: TLabel;
    procedure cmbUserTypeChange(Sender: TObject);
    procedure btnLogInClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure edtUsernameChange(Sender: TObject);
    procedure chxPremiumClick(Sender: TObject);

  private
    { Private declarations }
  public
    { Public declarations }
    procedure CreateAccount;
  end;

var
  frmLogin: TfrmLogin;

implementation

{$R *.dfm}

procedure TfrmLogin.btnLogInClick(Sender: TObject);
var sInput : String;
    i: Integer;
    bValidPassword : Boolean;
begin
if Length(edtUsername.text) < 1 then    //Checks if edit is empty
  begin
  Showmessage('Enter a username');
  edtUsername.setfocus;
  Exit;
  end;
if length(edtUserName.Text) > 25 then  //Checks if the entered username is more than 25 characters long
  begin
  Showmessage('Username is too long. Must be 25 characters or less.');
  edtUsername.SetFocus;
  Exit;
  end;

if sAccountAction = 'None' then
  begin
  frmMainPage.show;   //Opens the calculator form without creating or logging into an account
  frmLogin.hide;
  Exit;
  end;

if sAccountAction = 'Login' then
  begin
  slUser := TStringList.Create;   //Creates a string list variable
  slUser.LoadFromFile(sPath);      //Puts the textfile into a string list variable
  sPassword := slUser[1];     //Extracts the second line of the string list
  sInput := InputBox(sUsername,'Enter your password','');
  if sInput = sPassword then
    begin
    frmMainPage.Show;
    frmLogin.Hide;
    Exit;
    end
  else
    begin
    Showmessage('Incorrect password');
    Exit;
    end;
  end;

if (sAccountAction = 'Create') and (sUserType = 'Admin') then
  begin
  if edtAdminPassword.Text <> sAdminPassword then     //Checks if the admin password is correct
    begin
    Showmessage('Admin password incorrect');
    edtAdminPassword.SetFocus;
    Exit;
    end;

  bValidPassword := False; //Initialises the password input to invalid
  sPassword := Trim( InputBox(sUsername,'Create a password','') );    //Prompts the user to create a password
  for i := 1 to Length(sPassword) do
    begin
    if sPassword[i] in ['!','@','#','?'] then   //Checks if the password the user entered has a special character
      bValidPassword := True;
    end;
  if bValidPassword = False then
    begin
    Showmessage('Your password must contain at least 1 special character'+#10#13+'(!, @, #, ?)');
    Exit;
    end;

  CreateAccount; //Calls the procedure that creates the account textfile

  frmMainPage.Show;
  frmLogin.Hide;
  Exit;
  end;

if (sAccountAction = 'Create') and bPremium then
  begin
  frmPaywall.ShowModal;
  end;

end;

procedure TfrmLogin.chxPremiumClick(Sender: TObject);
begin
if chxPremium.Checked then
  begin
  bPremium := True;
  sUserType := 'Premium';
  end
else
  begin
  bPremium := False;
  sAccountAction := 'None';
  end;

edtUsernameChange(Sender);
end;

procedure TfrmLogin.cmbUserTypeChange(Sender: TObject);
begin
case cmbUserType.itemindex of             //Checks if user type User (0) or Admin (1) is selected
0 : begin
    edtAdminPassword.visible := False;    //If user type User is selected,  hide the password edit box,
    lblAdminPassword.visible := False;    //                                hide the label,
    chxPremium.visible := True;           //                                show the premium checkbox,
    sUserType := 'Basic';                 //                                store the user type and
    bUnlocked := False;                   //                                lock premium features.
    end;

1 : begin
    edtAdminPassword.visible := True;     //If user type Admin is selected, show the password edit box,
    lblAdminPassword.visible := True;     //                                show the label,
    chxPremium.visible := False;          //                                hide the premium checkbox and
    sUserType := 'Admin';                 //                                store the user type.
    end;
end;
edtUsername.SetFocus;    //Sets focus to edtUsername
btnLogin.visible := True;   //Shows the login button
chxPremium.Checked := False;
edtUsernameChange(Sender);    //Runs the code that runs when edtUsername is changed
end;

procedure TfrmLogin.CreateAccount;
begin
sPath := ExtractFilePath(ParamStr(0))+'Users\'+sUsername+'.txt';  //Grabs the root file path plus the username text file.

slUser := TStringList.Create;
  slUser.Add(sUsername);   //Adds the username to the top line
  slUser.Add(sPassword);   //Adds the password to the second line
  slUser.Add(sUserType);   //Adds the user type to the third line
  slUser.Add('');
  slUser.Add('Spending');
  slUser.Add('Amount:'+#9+'Tag'+#9+'(Rate�Inputs)');
  slUser.Add('------------------------------------');
  slUser.Add('------------------------------------');
  slUser.Add('Total:');
  slUser.Add('R0');
  slUser.SaveToFile(sPath);
end;

procedure TfrmLogin.edtUsernameChange(Sender: TObject);
begin
sUsername := edtUsername.text;    //Stores the username in a global variable
sPath := ExtractFilePath(ParamStr(0))+'Users\'+sUsername+'.txt';  //Grabs the root file path plus the username text file.

if (sUserType = 'Admin') or bPremium then     //Checks if the user is trying to log in as Admin or Premium
  begin
  if FileExists(sPath) then        //Checks if the username exists in the Users folder
    begin
    sAccountAction := 'Login';

    lblTaken.Font.Color := clRed;
    lblTaken.Caption := 'Taken';
    btnLogin.Caption := 'Log in';
    end
  else          //If the user chooses admin or premium and the username is taken, they can log in. If it is not taken, they can create an account
    begin
    sAccountAction := 'Create';

    lblTaken.Font.Color := clLime;
    lblTaken.Caption := 'Available';
    btnLogin.Caption := 'Sign up';
    end;
  end
else
  begin
  sAccountAction := 'None';  //If the user chooses regular user and no premium, no account check is done. The user may simply start using the program.

  lblTaken.Caption := '';
  btnLogin.Caption := 'Log in';
  end;

end;

procedure TfrmLogin.FormCreate(Sender: TObject);
begin
bPremium := False; //Initialises bPremium to False
bUnlocked := False;               //Initialises premium features as locked by default.
sAccountAction := 'None'; //Initialises user as free user (create no account).
sUserType := 'Basic';

AssignFile(tfAdminPassword,'adminpassword.txt') ;   //Asigns the text file to tfAdminPassword
Reset(tfAdminPassword);     //Opens the textfile that contains the admin password
try
  ReadLn(tfAdminPassword,sAdminPassword) ;   //Stores the password in sAdminPassword
finally
  CloseFile(tfAdminPassword);        //Closes the file
end;


end;

end.
