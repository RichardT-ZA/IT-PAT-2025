﻿//Richard Thiart
unit MainPage_u;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ExtCtrls,
  Vcl.Samples.Spin, Vcl.ComCtrls, math, GlobalVariables_u, VclTee.TeeGDIPlus,
  VCLTee.TeEngine, VCLTee.TeeProcs, VCLTee.Chart, VCLTee.Series, ShellAPI,
  Vcl.WinXCtrls, Vcl.Buttons, Vcl.Imaging.jpeg, Vcl.Imaging.pngimage, System.UITypes,MMSystem;

type
  TfrmMainPage = class(TForm)
    pgcMain: TPageControl;
    tabCalculator: TTabSheet;
    tabSettings: TTabSheet;
    tabAdmin: TTabSheet;
    pnlAdvancedCalculator: TPanel;
    lblConversionsTitle: TLabel;
    lblDegrees: TLabel;
    lblLog: TLabel;
    lblBracket: TLabel;
    edtTrig: TEdit;
    edtExp1: TEdit;
    edtExp2: TEdit;
    btnCalcExponents: TButton;
    redAnswers: TRichEdit;
    btnDiv: TButton;
    sedDiv1: TSpinEdit;
    sedDiv2: TSpinEdit;
    sedMod1: TSpinEdit;
    btnMod: TButton;
    sedMod2: TSpinEdit;
    btnSine: TButton;
    btnCosine: TButton;
    btnTangent: TButton;
    edtConversions: TEdit;
    btnBinaryToDecimal: TButton;
    btnDecimalToBinary: TButton;
    btnHexadecimalToDecimal: TButton;
    btnDecimalToHexadecimal: TButton;
    pnlBasicCalculator: TPanel;
    btn1: TButton;
    btn2: TButton;
    btn3: TButton;
    btn4: TButton;
    btn5: TButton;
    btn6: TButton;
    btn7: TButton;
    btn8: TButton;
    btn9: TButton;
    btn0: TButton;
    btnEquals: TButton;
    btnPlus: TButton;
    btnMinus: TButton;
    btnMultiply: TButton;
    btnDivide: TButton;
    btnBasicClear: TButton;
    memBasicCalculator: TMemo;
    pnlInvest: TPanel;
    lblInterestRateTitle: TLabel;
    lblPercent: TLabel;
    lblInvestAmount: TLabel;
    lblVolatility: TLabel;
    btnInvest: TButton;
    edtGrowthRate: TEdit;
    btnInvestCalculate: TButton;
    edtInvestAmount: TEdit;
    chartInvest: TChart;
    Data: TLineSeries;
    sedVolatility: TSpinEdit;
    redCost: TRichEdit;
    redFreeClicksLeft: TRichEdit;
    tmrAdvertisePremium: TTimer;
    shpWatermark: TShape;
    shpBackgroundColor: TShape;
    rgpBackgroundColour: TRadioGroup;
    tsCollectData: TToggleSwitch;
    lblCollectDataSetting: TLabel;
    tmrTurnDataCollectionBackOn: TTimer;
    tmrRainbowBackground: TTimer;
    shpCalculatorBackground: TShape;
    btnInvert: TButton;
    scrbxForm: TScrollBox;
    edtAdminPassword: TEdit;
    lblCrashed: TLabel;
    sedYears: TSpinEdit;
    lblYears: TLabel;
    lblAdminPassword: TLabel;
    lstUsers: TListBox;
    btnChargeUser: TButton;
    lstCostRates: TListBox;
    btnChangeCostRate: TButton;
    btnSaveCostRates: TButton;
    lblUnsaved: TLabel;
    btnUndoChanges: TButton;
    lblCostRatesLabel: TLabel;
    btnChangePassword: TButton;
    btnDeleteAccount: TButton;
    edtBalance: TEdit;
    redUserInfo: TRichEdit;
    btnLoadUsers: TButton;
    btnInvestInfo: TButton;
    btnBalanceInfo: TButton;
    btnFreeInfo: TButton;
    lblUsers: TLabel;
    lblUserData: TLabel;
    procedure FormCreate(Sender: TObject);
    procedure btnCalcExponentsClick(Sender: TObject);
    procedure btnDivClick(Sender: TObject);
    procedure btnModClick(Sender: TObject);
    procedure btnSineClick(Sender: TObject);
    procedure btnCosineClick(Sender: TObject);
    procedure btnTangentClick(Sender: TObject);
    procedure btnBinaryToDecimalClick(Sender: TObject);
    procedure btnDecimalToBinaryClick(Sender: TObject);
    procedure btnHexadecimalToDecimalClick(Sender: TObject);
    procedure btnDecimalToHexadecimalClick(Sender: TObject);
    procedure btnInvestClick(Sender: TObject);
    procedure btnBasicClearClick(Sender: TObject);
    procedure btn1Click(Sender: TObject);
    procedure btnPlusClick(Sender: TObject);
    procedure btnEqualsClick(Sender: TObject);
    procedure btn2Click(Sender: TObject);
    procedure btn3Click(Sender: TObject);
    procedure btn4Click(Sender: TObject);
    procedure btn5Click(Sender: TObject);
    procedure btn6Click(Sender: TObject);
    procedure btn7Click(Sender: TObject);
    procedure btn8Click(Sender: TObject);
    procedure btn9Click(Sender: TObject);
    procedure btn0Click(Sender: TObject);
    procedure btnMinusClick(Sender: TObject);
    procedure btnMultiplyClick(Sender: TObject);
    procedure btnDivideClick(Sender: TObject);
    procedure tmrAdvertisePremiumTimer(Sender: TObject);
    procedure shpWatermarkContextPopup(Sender: TObject; MousePos: TPoint;
      var Handled: Boolean);
    procedure btnInvestCalculateClick(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure rgpBackgroundColourClick(Sender: TObject);
    procedure tmrTurnDataCollectionBackOnTimer(Sender: TObject);
    procedure tmrRainbowBackgroundTimer(Sender: TObject);
    procedure tsCollectDataClick(Sender: TObject);
    procedure btnInvertClick(Sender: TObject);
    procedure FormResize(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure edtAdminPasswordChange(Sender: TObject);
    procedure btnChargeUserClick(Sender: TObject);
    procedure btnChangeCostRateClick(Sender: TObject);
    procedure btnSaveCostRatesClick(Sender: TObject);
    procedure btnUndoChangesClick(Sender: TObject);
    procedure btnChangePasswordClick(Sender: TObject);
    procedure btnDeleteAccountClick(Sender: TObject);
    procedure btnLoadUsersClick(Sender: TObject);
    procedure lstUsersClick(Sender: TObject);
    procedure btnInvestInfoClick(Sender: TObject);
    procedure btnBalanceInfoClick(Sender: TObject);
    procedure btnFreeInfoClick(Sender: TObject);

  private
    { Private declarations }
    var iFreePlusUses, iFreeMinusUses, iFreeMultiplyUses, iFreeDivideUses, iBasicCalcStep: Integer;
        curTotalCost, curOutstandingBalance : Currency;
        iBasicInput1, iBasicInput2 : Int64;
        sBasicInput1, sBasicInput2, sBasicCalculation : String;
        bPay, bInvertedCalc : Boolean;

    procedure RefreshFreeUses;
    procedure UpdateCostRates;
    procedure UpdateCost(rRate : Real; rAmount: Real; sTag : String);
    procedure LockFeatures;
    procedure Invest(rAmount : Double; bShowmessage : Boolean) ;
    function Subscript(iInput: Integer) : String ;
    function FlipBool(bInput : Boolean) : Boolean ;
  public
    { Public declarations }
    procedure BasicCalculation(sNumber : String) ;
  end;

var
  frmMainPage: TfrmMainPage;

implementation

uses
  login_u, Paywall_u;   //The other 2 forms are referenced here instead of under Interface -> Uses to avoid a circular reference

{$R *.dfm}

procedure TfrmMainPage.btnCosineClick(Sender: TObject);
var rInput, rAnswer : Double;
begin
if bUnlocked = False then      //Checks if premium features are unlocked
  begin
  frmPaywall.ShowModal;          //If not unlocked, show the paywall form
  Exit;
  end;

if Length(edtTrig.Text) < 1 then
  begin
  Showmessage('No input');
  edtTrig.SetFocus;
  Exit;
  end;

if not TryStrToFloat(edtTrig.Text, rInput) then
  begin
  Showmessage(edtTrig.Text+' is not a number.');
  edtTrig.SetFocus;
  Exit;
  end;

if bInvertedCalc then
  begin
  rAnswer := RadToDeg(ArcCos(rInput)); ;  //Delphi works with radians when doing trig and I want to work with degrees so RadToDeg (Radians to degrees) is needed
  redAnswers.Lines.Add( 'Cos⁻¹('+FloatToStr(rInput)+') = '+FloatToStrF(rAnswer,fffixed,8,2)+'°' );   //Displays answer
  end
else
  begin
  rAnswer := Cos(DegToRad(rInput)); //Delphi works with radians and I want to work with degrees. That's why the function DegToRad (Degrees to radians) is needed
  redAnswers.Lines.Add( 'Cos('+FloatToStr(rInput)+'°) = '+FloatToStrF(rAnswer,fffixed,8,5));     //Displays answer
  end;

UpdateCost(CosCost,rInput,'Cos');
end;

procedure TfrmMainPage.btnDecimalToBinaryClick(Sender: TObject);
var sInput, sBinary : String;
    iInput, iNum : Int64;  //Int64 allows you to work with bigger numbers than the regular Integer datatype
begin
if bUnlocked = False then
  begin
  frmPaywall.ShowModal;
  Exit;
  end;

sInput := StringReplace(edtConversions.Text,'-','',[rfReplaceAll]);   //Removes the - if there is one
edtConversions.Text := sInput ; //Replaces the negative input with a positive one

if Length(sInput) < 1 then   //Checks if there is something in the input edit box
  begin
  Showmessage('No inputs');
  edtConversions.setfocus;
  Exit;
  end;

if not TryStrToInt64(sInput, iInput) then    //Checks if the input is a number
  begin
  Showmessage(sInput+' is not an integer.');
  edtConversions.setfocus;
  Exit;
  end;

sBinary := '';
iNum := iInput;
Repeat
  sBinary := IntToStr( iNum mod 2 ) + sBinary;
  iNum := iNum div 2;
Until iNum = 0 ;

redAnswers.lines.add(sInput+'₁₀ = '+sBinary+'₂');
UpdateCost(ConvertCost,iInput,'Convert');
end;

procedure TfrmMainPage.btnDecimalToHexadecimalClick(Sender: TObject);
var sInput, sHex, sChar : String;
    iInput, iNum, iChar : Int64;  //Int64 allows you to work with bigger numbers than the regular Integer datatype
begin
if bUnlocked = False then
  begin
  frmPaywall.ShowModal;
  Exit;
  end;

sInput := StringReplace(edtConversions.Text,'-','',[rfReplaceAll]);   //Removes the - if there is one
edtConversions.Text := sInput ; //Replaces the negative input with a positive one

if Length(sInput) < 1 then   //Checks if there is something in the input edit box
  begin
  Showmessage('No inputs');
  edtConversions.setfocus;
  Exit;
  end;

if not TryStrToInt64(sInput, iInput) then    //Checks if the input is a number
  begin
  Showmessage(sInput+' is not an integer.');
  edtConversions.setfocus;
  Exit;
  end;

sHex := '';
iNum := iInput;
Repeat                                 //Builds the hexadecimal number
  iChar := iNum mod 16 ;
  case iChar of
  0..9 : sChar := IntToStr(iChar) ;
  10 : sChar := 'A';
  11 : sChar := 'B';
  12 : sChar := 'C';
  13 : sChar := 'D';
  14 : sChar := 'E';
  15 : sChar := 'F';
  end;

  sHex := sChar + sHex;
  iNum := iNum div 16;
Until iNum = 0 ;

redAnswers.lines.Add(sInput+'₁₀ = '+sHex+'₁₆');    //Displays the answer
UpdateCost(ConvertCost,StrToInt(sInput),'Convert') ;
end;

procedure TfrmMainPage.btnDeleteAccountClick(Sender: TObject);
var iResponse : Integer;
begin
iResponse := MessageDlg('Are you sure you want to delete your account and all of its data?',TMsgDlgType.mtConfirmation,[mbYes,mbNo],0) ;
if iResponse = mrYes then
  begin
  DeleteFile(sPath);
  frmMainPage.Close;
  end;

end;

procedure TfrmMainPage.BasicCalculation(sNumber: String);
begin
memBasicCalculator.Clear ;
if ibasicCalcStep = 1 then
  begin
  sBasicInput1 := sBasicInput1 + sNumber;              //Step 1: Input 1
  memBasicCalculator.lines.Add(sBasicInput1) ;

  btnPlus.Enabled := True;                         //Allows user to pick a calculation ( + - x / )
  btnMinus.Enabled := True;
  btnMultiply.Enabled := True;
  btnDivide.Enabled := True;
  end
else
  begin
  sBasicInput2 := sBasicInput2 + sNumber;              //Step 2: Input 2
  memBasicCalculator.lines.Add(sBasicInput1+sBasicCalculation+sBasicInput2) ;

  btnEquals.Enabled := True;                       //Allows user to calculate the answer
  btnPlus.Enabled := False;
  btnMinus.Enabled := False;
  btnMultiply.Enabled := False;
  btnDivide.Enabled := False;
  end;

Lockfeatures;
end;

procedure TfrmMainPage.btn0Click(Sender: TObject);
begin
BasicCalculation('0')
end;

procedure TfrmMainPage.btn1Click(Sender: TObject);
begin
BasicCalculation('1') ;
end;

procedure TfrmMainPage.btn2Click(Sender: TObject);
begin
BasicCalculation('2')
end;

procedure TfrmMainPage.btn3Click(Sender: TObject);
begin
BasicCalculation('3')
end;

procedure TfrmMainPage.btn4Click(Sender: TObject);
begin
BasicCalculation('4')
end;

procedure TfrmMainPage.btn5Click(Sender: TObject);
begin
BasicCalculation('5')
end;

procedure TfrmMainPage.btn6Click(Sender: TObject);
begin
BasicCalculation('6')
end;

procedure TfrmMainPage.btn7Click(Sender: TObject);
begin
BasicCalculation('7')
end;

procedure TfrmMainPage.btn8Click(Sender: TObject);
begin
BasicCalculation('8')
end;

procedure TfrmMainPage.btn9Click(Sender: TObject);
begin
BasicCalculation('9')
end;

procedure TfrmMainPage.btnBalanceInfoClick(Sender: TObject);
begin
Showmessage('The Total is the total amount of money you spent on this app in all sessions combined.'+#13+
            'The Outstanding Balance is how much you spent in this session of the app.'+#13#13+
            'Once you close the app you end the session and your outstanding balance will be charged to your card');
end;

procedure TfrmMainPage.btnBasicClearClick(Sender: TObject);
begin
sBasicInput1 := '';
sBasicInput2 := '';
memBasicCalculator.Clear ;

if bUnlocked = False then

btnPlus.Enabled := False;
btnMinus.Enabled := False;
btnMultiply.Enabled := False;
btnDivide.Enabled := False;
btnEquals.Enabled := False;
iBasicCalcStep := 1;

btn0.Enabled := True;
btn1.Enabled := True;
btn2.Enabled := True;
btn3.Enabled := True;
btn4.Enabled := True;
btn5.Enabled := True;
btn6.Enabled := True;
btn7.Enabled := True;
btn8.Enabled := True;
btn9.Enabled := True;

memBasicCalculator.Alignment := taCenter ;
btnBasicClear.font.style := [] ;
end;

procedure TfrmMainPage.btnDivClick(Sender: TObject);
var i1, i2, iAnswer : Int64;
begin
if bUnlocked = False then
  begin
  frmPaywall.ShowModal;
  Exit;
  end;

i1 := sedDiv1.value;
i2 := sedDiv2.value;

iAnswer := i1 DIV i2;

redAnswers.lines.add(IntToStr(i1)+' DIV '+IntToStr(i2)+' = '+IntToStr(iAnswer));

UpdateCost(DivCost,i1+i2,'Div');
end;

procedure TfrmMainPage.btnDivideClick(Sender: TObject);
begin
sBasicCalculation := ' ÷ ';
iBasicCalcStep := 2;
memBasicCalculator.lines.Add(sBasicInput1+sBasiccalculation+sBasicInput2) ;

btnPlus.Enabled := False;
btnMinus.Enabled := False;
btnMultiply.Enabled := False;
btnDivide.Enabled := False;

if iFreeDivideUses < 1 then
  begin
  bPay := True;
  end
else
  begin
  bPay := False;
  end;

if (bUnlocked = False) and (iFreeDivideUses = 1) then
  tmrAdvertisePremium.Enabled := True;
end;

procedure TfrmMainPage.btnEqualsClick(Sender: TObject);
var rRate, rAnswer : Double;
    sTag : String ;
begin
if (Length(sBasicInput1) > 8) or (Length(sBasicInput2) > 8) then
  begin
  Showmessage('Inputs too large. Cannot be more than 8 digits per input.');
  btnBasicClearClick(Sender);
  Exit;
  end;

memBasicCalculator.Clear ;

iBasicInput1 := StrToInt(sBasicInput1);          //Input
iBasicInput2 := StrToInt(sBasicInput2);

if sBasicCalculation = ' + ' then                  //Calculation
  begin
  rAnswer := iBasicInput1 + iBasicInput2 ;
  rRate := PlusCost ;
  iFreePlusUses := iFreePlusUses -1 ;
  sTag := 'Plus' ;
  end
else if sBasicCalculation = ' - ' then
  begin
  rAnswer := iBasicInput1 - iBasicInput2 ;
  rRate := MinusCost ;
  iFreeMinusUses := iFreeMinusUses -1 ;
  sTag := 'Minus' ;
  end
else if sBasicCalculation = ' x ' then
  begin
  rAnswer := iBasicInput1 * iBasicInput2 ;
  rRate := MultiplyCost ;
  iFreeMultiplyUses := iFreeMultiplyUses -1 ;
  sTag := 'Multiply' ;
  end
else if sBasicCalculation = ' ÷ ' then
  begin
  rAnswer := iBasicInput1 / iBasicInput2 ;
  rRate := DivideCost ;
  iFreeDivideUses := iFreeDivideUses -1 ;
  sTag := 'Divide' ;
  end;
                        //Displays answer
memBasicCalculator.Lines.Add(sBasicInput1+sBasicCalculation+sBasicInput2+#13#10+'= '+FloatToStrF(rAnswer,fffixed,8,2)) ;
memBasicCalculator.Alignment := taLeftJustify ;
btnBasicClear.Font.Style := [fsBold] ;

btn0.Enabled := False;                            //Disable buttons
btn1.Enabled := False;
btn2.Enabled := False;
btn3.Enabled := False;
btn4.Enabled := False;
btn5.Enabled := False;
btn6.Enabled := False;
btn7.Enabled := False;
btn8.Enabled := False;
btn9.Enabled := False;
btnEquals.Enabled := False;

RefreshFreeUses;

if bPay then
  begin
  UpdateCost(rRate,iBasicInput1+iBasicInput2,sTag);
  end;
end;

procedure TfrmMainPage.btnFreeInfoClick(Sender: TObject);
begin
Showmessage('You have a limited number of free calculations you can do with the basic calculator before you have to start paying.');
end;

procedure TfrmMainPage.btnHexadecimalToDecimalClick(Sender: TObject);
var sInput : String;
    i, iDeciNum, iCounter, iChar : Int64;  //Int64 allows you to work with bigger numbers than the regular Integer datatype
    bIsHex : Boolean;
begin
if bUnlocked = False then
  begin
  frmPaywall.ShowModal;
  Exit;
  end;

sInput := StringReplace(edtConversions.Text,'-','',[rfReplaceAll]);   //Removes the - if there is one
edtConversions.Text := sInput ; //Replaces the negative input with a positive one

if Length(sInput) < 1 then   //Checks if there is something in the input edit box
  begin
  Showmessage('No inputs');
  edtConversions.setfocus;
  Exit;
  end;

bIsHex := True;
for i := 1 to Length(sInput) do      //Checks if the input is a Hex number
  begin
  if not (sInput[i] in ['0'..'9','A'..'F']) then
    bIsHex := False;
  end;
if bIsHex = False then
  begin
  Showmessage(sInput+' is not a Hexadecimal number.');
  edtConversions.SetFocus;
  Exit;
  end;

iDecinum := 0;                                                        //              4096     256     16    1
iCounter := 0;                                                        //              16^3     16^2    16^1  16^0
for i := Length(sInput) downto 1 do                                   //Example:      2        A       5     C
  begin                                                               //              2*4096   10*256  5*16  12*1                                                                      //              8192  +  2560 +  80 +  12    = 10844
    case sInput[i] of
    '0'..'9' : iChar := StrToInt(sInput[i]) ;        //Conversion
    'A' : iChar := 10 ;
    'B' : iChar := 11 ;
    'C' : iChar := 12 ;
    'D' : iChar := 13 ;
    'E' : iChar := 14 ;
    'F' : iChar := 15 ;
    end;
  iDeciNum := iChar * Trunc(Power(16,iCounter)) + iDeciNum ;
  Inc(iCounter);
  end;

redAnswers.lines.add(sInput+'₁₆ = '+IntToStr(iDeciNum)+'₁₀') ;
UpdateCost(ConvertCost,iDeciNum,'Convert') ;
end;

procedure TfrmMainPage.btnInvestClick(Sender: TObject);
var rRate, rAmount, rVolatility, rValue, rPreValue : Double;
    i, iRange, iYears : Integer;
    arrValue : array of Double ;
    sTotal, sWorth, sFutureYear, sRate, sMessage : String ;
begin
if bUnlocked = False then   //Checks if you are on the free version
  begin
  Showmessage('You are currently using a free version of Capitalistic Calculator. Your total will remain at R0. Consider signing up for premium!');
  frmPaywall.ShowModal;
  Exit;
  end;

Invest(curTotalCost, True);  //Calls my custom invest procedure. Takes the total spent on this app as an input (curTotalCost). True = A showmessage with a summary will appear
end;

procedure TfrmMainPage.btnInvestInfoClick(Sender: TObject);
begin
Showmessage('Click the Invest! button to use the total amount you spent on this app.'+#13+
            'Click the Calculate button to use a custom amount'+#13#13+
            'Growth rate: The annual rate at which your investment grows'+#13#13+
            'Years: How many years you want to show on the chart'+#13#13+
            'Volatility:'+#13+'How quickly the value of your investment can change. Volatility set to 100 means your investment can double in value or drop to 0 in the next year. Volatility set to 0 gives you a clean exponential curve with no bumps and random ups and downs.'+#13+
            'More volatility = More risk'+#13#13+
            'Amount: You can set a custom investment amount and watch it grow');
end;

procedure TfrmMainPage.btnLoadUsersClick(Sender: TObject);
var
  sFolder: string;
  srFile: TSearchRec;
  slUsers: TStringList;
  sName: string;
begin
lstUsers.Items.Clear;

sFolder := ExtractFilePath(ParamStr(0)) + 'Users\';  //Grabs the file path of the Users folder

if FindFirst(sFolder + '*.txt', faAnyFile, srFile) = 0 then  // Scan all text files in the folder
begin
  repeat
    slUsers := TStringList.Create;
    try
      slUsers.LoadFromFile(sFolder + srFile.Name);
      if slUsers.Count > 0 then
        sName := slUsers[0]  //First line of the file is the username
      else
        sName := ChangeFileExt(srFile.Name, '');
      lstUsers.Items.Add(sName);
    finally
      slUsers.Free;
    end;
  until FindNext(srFile) <> 0;
  FindClose(srFile);
end;

end;

procedure TfrmMainPage.btnMinusClick(Sender: TObject);
begin
sBasicCalculation := ' - ';
iBasicCalcStep := 2;
memBasicCalculator.text := sBasicInput1+sBasicCalculation;

btnPlus.Enabled := False;
btnMinus.Enabled := False;
btnMultiply.Enabled := False;
btnDivide.Enabled := False;

if iFreeMinusUses < 1 then
  begin
  bPay := True;
  end
else
  begin
  bPay := False;
  end;

if (bUnlocked = False) and (iFreeMinusUses = 1) then
  tmrAdvertisePremium.Enabled := True;
end;

procedure TfrmMainPage.btnModClick(Sender: TObject);
var i1, i2, iAnswer: Int64;
begin
if bUnlocked = False then
  begin
  frmPaywall.ShowModal;
  Exit;
  end;

i1 := sedMod1.value;
i2 := sedMod2.value;

iAnswer := i1 MOD i2;

redAnswers.lines.add(IntToStr(i1)+' MOD '+IntToStr(i2)+' = '+IntToStr(iAnswer));

UpdateCost(ModCost,i1+i2,'Mod');
end;

procedure TfrmMainPage.btnMultiplyClick(Sender: TObject);
begin
sBasicCalculation := ' x ';
iBasicCalcStep := 2;
memBasicCalculator.text := sBasicInput1+sBasicCalculation;

btnPlus.Enabled := False;
btnMinus.Enabled := False;
btnMultiply.Enabled := False;
btnDivide.Enabled := False;

if iFreeMultiplyUses < 1 then
  begin
  bPay := True;
  end
else
  begin
  bPay := False;
  end;

if (bUnlocked = False) and (iFreeMultiplyUses = 1) then
  tmrAdvertisePremium.Enabled := True;
end;

procedure TfrmMainPage.btnPlusClick(Sender: TObject);
begin
sBasicCalculation := ' + ';
iBasicCalcStep := 2;
memBasicCalculator.text := sBasicInput1+sBasicCalculation;

btnPlus.Enabled := False;
btnMinus.Enabled := False;
btnMultiply.Enabled := False;
btnDivide.Enabled := False;

if iFreePlusUses < 1 then
  begin
  bPay := True;
  end
else
  begin
  bPay := False;
  end;

if (bUnlocked = False) and (iFreePlusUses = 1) then
  tmrAdvertisePremium.Enabled := True;
end;

procedure TfrmMainPage.btnSaveCostRatesClick(Sender: TObject);
begin
if not (sUserType = 'Admin') then
  begin
  Showmessage('You are not an admin');
  Exit;
  end;

lstCostRates.Items.SaveToFile('costrates.txt');    //Stores the listbox data to the text file
UpdateCostRates;

btnUndoChanges.Enabled := False;
lblUnsaved.Caption := 'Saved';
lblUnsaved.Font.Color := clGreen;
end;

procedure TfrmMainPage.btnSineClick(Sender: TObject);
var rInput, rAnswer : Double;
begin
if bUnlocked = False then
  begin
  frmPaywall.ShowModal;
  Exit;
  end;

if Length(edtTrig.Text) < 1 then  //Checks if the edit is empty
  begin
  Showmessage('No input');
  edtTrig.SetFocus;
  Exit;
  end;

if not TryStrToFloat(edtTrig.Text, rInput) then   //Checks if the input is a number
  begin
  Showmessage(edtTrig.Text+' is not a number.');
  edtTrig.SetFocus;
  Exit;
  end;

if bInvertedCalc then
  begin
  rAnswer := RadToDeg(ArcSin(rInput));  //Delphi works with radians when doing trig and I want to work with degrees so RadToDeg (Radians to degrees) is needed
  redAnswers.Lines.Add( 'Sin⁻¹('+FloatToStr(rInput)+') = '+FloatToStrF(rAnswer,fffixed,8,2)+'°' ) ;   //Displays answer
  end
else
  begin
  rAnswer := Sin(DegToRad(rInput)) ; //Delphi works with radians and I want to work with degrees. That's why the function DegToRad (Degrees to radians) is needed
  redAnswers.Lines.Add( 'Sin('+FloatToStr(rInput)+'°) = '+FloatToStrF(rAnswer,fffixed,8,5)) ;     //Displays answer
  end;

UpdateCost(SinCost,rInput,'Sin');
end;

procedure TfrmMainPage.btnTangentClick(Sender: TObject);
var rInput, rAnswer : Double;
begin
if bUnlocked = False then
  begin
  frmPaywall.ShowModal;   //Opens paywall screen
  Exit;
  end;

if Length(edtTrig.Text) < 1 then   //Checks if the edit is empty
  begin
  Showmessage('No input');
  edtTrig.SetFocus;
  Exit;
  end;

if not TryStrToFloat(edtTrig.Text, rInput) then      //Checks if the input is a number
  begin
  Showmessage(edtTrig.Text+' is not a number.');
  edtTrig.SetFocus;
  Exit;
  end;

if bInvertedCalc then
  begin
  rAnswer := RadToDeg(ArcTan(rInput));  //Delphi works with radians when doing trig and I want to work with degrees so RadToDeg (Radians to degrees) is needed
  redAnswers.Lines.Add( 'Tan⁻¹('+FloatToStr(rInput)+') = '+FloatToStrF(rAnswer,fffixed,8,2)+'°' );   //Displays answer
  end
else
  begin
  rAnswer := Tan(DegToRad(rInput)); //Delphi works with radians and I want to work with degrees. That's why the function DegToRad (Degrees to radians) is needed
  if (rAnswer > 99999999) or (rAnswer < -99999999) then  //Checks if output is undefined (Tan90 for example returns a very large number)
    begin
    redAnswers.Lines.Add( 'Tan('+FloatToStr(rInput)+'°) = Undefined' ); //Displays the answer as undefined
    end
  else
    redAnswers.Lines.Add( 'Tan('+FloatToStr(rInput)+'°) = '+FloatToStrF(rAnswer,fffixed,8,5)) ;     //Displays answer
  end;

UpdateCost(TanCost,rInput,'Tan');
end;

procedure TfrmMainPage.btnUndoChangesClick(Sender: TObject);
begin
lstCostRates.Items.LoadFromFile('costrates.txt'); //Loads the current cost rates into the listbox in settings
btnUndoChanges.Enabled := False;  //Disables the button
lblUnsaved.Caption := '';         //Takes away the text "Unsaved changes"
end;

procedure TfrmMainPage.Button1Click(Sender: TObject);
begin
Showmessage(sAdminPassword);
end;

procedure TfrmMainPage.edtAdminPasswordChange(Sender: TObject);
begin
sAdminPassword := edtAdminPassword.Text;

AssignFile(tfAdminPassword,'adminpassword.txt') ;   //Asigns the text file to tfAdminPassword
Rewrite(tfAdminPassword);     //Opens the textfile to overwrite it
try
  WriteLn(tfAdminPassword,sAdminPassword) ;   //Stores the password in sAdminPassword
finally
  CloseFile(tfAdminPassword);        //Closes the file
end;
end;

procedure TfrmMainPage.btnInvertClick(Sender: TObject);
begin
bInvertedCalc := FlipBool(bInvertedCalc) ;
if bInvertedCalc = True then
  begin
  lblLog.Visible := True ;      //Switches to Log
  lblBracket.Visible := True ;
  edtExp1.Top := 43 ;
  edtExp1.Left := 95 ;
  edtExp2.Top := 54 ;
  edtExp2.Left := 55 ;
  btnInvert.Caption := '↪' ;
  edtExp1.TextHint := '' ;
  edtExp2.TextHint := 'Base' ;

  btnSine.Caption := 'sin⁻¹' ;   //Switches to inverse trig
  btnCosine.Caption := 'cos⁻¹' ;
  btnTangent.Caption := 'tan⁻¹' ;
  lblDegrees.Visible := False ;
  end
else
  begin
  lblLog.Visible := False ;        //Switches to Exponentiation
  lblBracket.Visible := False ;
  edtExp1.Top := 47 ;
  edtExp1.Left := 73 ;
  edtExp2.Top := 31 ;
  edtExp2.Left := 130 ;
  btnInvert.Caption := '↩' ;
  edtExp1.TextHint := 'Base' ;
  edtExp2.TextHint := 'Exp' ;

  btnSine.Caption := 'sin' ;   //Switches to regular trig
  btnCosine.Caption := 'cos' ;
  btnTangent.Caption := 'tan' ;
  lblDegrees.Visible := True ;
  end;

end;

procedure TfrmMainPage.btnInvestCalculateClick(Sender: TObject);
var rAmount : Double;  //I have to declare rAmount as a double otherwise TryStrToFloat doesn't work
begin
if bUnlocked = False then
  begin
  frmPaywall.ShowModal;
  Exit;
  end;

if not TryStrToFloat(edtInvestAmount.text,rAmount) then //Checks if the input in edtInvestAmount is a Real/Double
  begin                                                 // and stores it in rAmount
  edtInvestAmount.Text := '';
  Showmessage('Please enter an amount.') ;
  edtInvestAmount.setfocus ;
  Exit;
  end;

rAmount := Abs(rAmount);                      //Prevents user from using negative numbers
edtInvestAmount.Text := FloatToStr(rAmount);

Invest(rAmount, False);  //Calls my custom Invest procedure. The first argument is the starting amount, the second is whether a showmessage with a summary should appear
end;

procedure TfrmMainPage.UpdateCost;
var rCost : Real;
    sNewEntry, sNewTotal : String;
    i : Integer;
begin
rRate := Abs(rRate);    //Prevents cost from being negative if inputs are negative numbers
rAmount := Abs(rAmount);

rCost := rRate*rAmount;
curTotalCost := curTotalCost + rCost;
curOutstandingBalance := curOutstandingBalance + rCost;
sNewEntry := FloatToStrF(rCost,ffCurrency,8,2)+#9+sTag+#9+'('+FloatToStr(rRate)+'×'+FloatToStr(rAmount)+')';
sNewTotal := 'Total:'+#13+CurrToStrF(curTotalCost,ffCurrency,2);   //TotalCost uses datatype Currency and CurrToStrF instead of real to prevent it from using scientific notation ( 0.12562E9 ) and adds a space after every 3 digits

for i := 1 to 3 do
  begin
  redCost.lines.Delete(redCost.lines.count-1);
  end;

redCost.Paragraph.TabCount := 2;   //Sets tab count to 2
redCost.Paragraph.Tab[0] := 75;    //Sets first tab position
redCost.Paragraph.Tab[1] := 120;   //Sets second tab position

redCost.lines.Add(sNewEntry);
redCost.lines.Add('------------------------------------');
redCost.lines.Add(sNewTotal);

redCost.Lines.SaveToFile(sPath, TEncoding.ANSI); //Updates the user's text file. TTEncoding.ANSI is needed to prevent delphi from saving formatting of the rich edit to the text file

edtBalance.Text := 'Outstanding Balance: '+CurrToStrF(curOutstandingBalance,ffCurrency,2);
end;

procedure TfrmMainPage.UpdateCostRates;
begin
PlusCost := StrToFloat(Copy(lstCostRates.Items[0],1,4));    //Stores the cost rates into variables
MinusCost := StrToFloat(Copy(lstCostRates.Items[1],1,4));
MultiplyCost := StrToFloat(Copy(lstCostRates.Items[2],1,4));
DivideCost := StrToFloat(Copy(lstCostRates.Items[3],1,4));
ExponentCost := StrToFloat(Copy(lstCostRates.Items[4],1,4));
LogCost := StrToFloat(Copy(lstCostRates.Items[5],1,4));
DivCost := StrToFloat(Copy(lstCostRates.Items[6],1,4));
ModCost := StrToFloat(Copy(lstCostRates.Items[7],1,4));
SinCost := StrToFloat(Copy(lstCostRates.Items[8],1,4));
CosCost := StrToFloat(Copy(lstCostRates.Items[9],1,4));
TanCost := StrToFloat(Copy(lstCostRates.Items[10],1,4));
ConvertCost := StrToFloat(Copy(lstCostRates.Items[11],1,4));
end;

procedure TfrmMainPage.btnBinaryToDecimalClick(Sender: TObject);
var sInput : String;
    iInput, i, iCounter, iDecimal, iChar : Int64; //Int64 allows you to work with bigger numbers than the regular Integer datatype
    bIsBinary : Boolean;
begin
if bUnlocked = False then
  begin
  frmPaywall.ShowModal;
  Exit;
  end;

sInput := StringReplace(edtConversions.Text,'-','',[rfReplaceAll]);   //Removes the - if there is one
edtConversions.Text := sInput ; //Replaces the negative input with a positive one

if Length(sInput) < 1 then   //Checks if there is something in the input edit box
  begin
  Showmessage('No inputs');
  edtConversions.setfocus;
  Exit;
  end;

if not TryStrToInt64(sInput, iInput) then    //Checks if the input is a number
  begin
  Showmessage(sInput+' is not an integer.');
  edtConversions.setfocus;
  Exit;
  end;

bIsBinary := True;
for i := 1 to Length(sInput) do            //Checks if the input is a binary number
  begin
  if not (sInput[i] in ['0','1']) then
    bIsBinary := False;
  end;
if bIsBinary = False then
  begin
  Showmessage(sInput+' is not a binary number.');
  edtConversions.SetFocus;
  Exit;
  end;

iCounter := 0;
iDecimal := 0;                                                  //           16  8   4   2   1
for i := length(sInput) downto 1 do                             //           2^4 2^3 2^2 2^1 2^0
  begin                                                         // Example:  1   1   0   1   1
  iChar := StrToInt(sInput[i]);                                 //           16+ 8 + 0 + 2 + 1 = 27
  case sInput[i] of
  '0' : iDecimal := iDecimal + 0;                                  //This line is redundant but I'm keeping it to serve as a simpler version of the Hexadecimal conversions which will have a similar structure
  '1' : iDecimal := iDecimal + iChar * Trunc(Power(2,iCounter)) ;  //iChar is also redundant since it will always be 1 here. You are just multiplying by 1 but I am keeping it like this for the structure
  end;
  Inc(iCounter);
  end;
redAnswers.lines.add(sInput+'₂ = '+IntToStr(iDecimal)+'₁₀');

UpdateCost(ConvertCost,iDecimal,'Convert');  //How much you pay for doing this calculation
end;

procedure TfrmMainPage.btnCalcExponentsClick(Sender: TObject);
var rInput1, rAnswer: Double;
    iInput2 : Integer;
    sTag : String ;
begin
if bUnlocked = False then
  begin
  frmPaywall.ShowModal;
  Exit;
  end;
              //Prevents user from calculating without inputs
if Length(edtExp1.Text) < 1 then
  begin
  Showmessage('No input.');
  edtExp1.SetFocus;
  Exit;
  end;
if Length(edtExp2.Text) < 1 then
  begin
  Showmessage('No input.');
  edtExp2.SetFocus;
  Exit;
  end;

if not TryStrToFloat(edtExp1.Text, rInput1) then
  begin
  Showmessage(edtExp1.Text+' is not a number.');
  edtExp1.SetFocus;
  Exit;
  end;

iInput2 := StrToInt(edtExp2.text);

if bInvertedCalc then                //Checks if the invert calculation button was clicked
  begin
  rAnswer := LogN(iInput2,rInput1) ; //Calculates the log
                                                             //Displays answer
  redAnswers.lines.add('Log'+Subscript(Trunc(iInput2))+'('+FloatToStrF(rInput1,FFFixed,8,2)+') = '+FloatToStrF(rAnswer,FFFixed,8,2)) ;
  sTag := 'Log' ;
  end
else
  begin
  rAnswer := Power(rInput1,iInput2); //Calculates the exponent
                                                                   //Displays answer
  redAnswers.lines.add(FloatToStr(rInput1)+'^'+ IntToStr(iInput2)+' = ' + FloatToStrF(rAnswer,fffixed,8,2));
  sTag := 'Exponent' ;
  end;


UpdateCost(ExponentCost,rInput1+iInput2,sTag);     //See price rates @ GlobalVariables_u
end;

procedure TfrmMainPage.btnChangeCostRateClick(Sender: TObject);
var sItem, sInput : String;
    iIndex : Integer;
    rNewPrice : Double;
begin
if not (sUserType = 'Admin') then        //Checks if the user is an admin
  begin
  Showmessage('You are not an admin');
  Exit;
  end;

iIndex := lstCostRates.ItemIndex;
if iIndex = -1 then
  begin
  Showmessage('Select a cost rate to change');
  Exit;
  end;

sItem := Copy( lstCostRates.Items[iIndex], 5, 20 );
if not TryStrToFloat(Inputbox('Change'+sItem,'Enter new price:',''), rNewPrice ) then  //Checks if the input is a number
  begin
  Showmessage('Invalid input');   //Breaks if input is not a number
  Exit;
  end;

if not ( (rNewPrice >= 0) and (rNewPrice <= 9.99) ) then         //Ensures that the price stays 4 characters e.g. 4.43, 0.30, 0.05, 0.00
  begin
  Showmessage('Cost rates must be a number from 0 to 9.99');
  Exit;
  end;

lstCostRates.Items[iIndex] := FloatToStrF(rNewPrice, ffFixed, 8, 2) + sItem;

lblUnsaved.Caption := 'Unsaved changes' ;
lblUnsaved.Font.Color := clRed;
btnUndoChanges.Enabled := True;
end;

procedure TfrmMainPage.btnChangePasswordClick(Sender: TObject);
begin
sPassword := InputBox(sUsername,'Enter a new password','');   //Prompts the user to enter a new password
redCost.Lines[1] := sPassword;   //Adds the password to the second line of redCost
redCost.Lines.SaveToFile(sPath, TEncoding.ANSI); //Updates the user's text file. TTEncoding.ANSI is needed to prevent delphi from saving formatting of the rich edit to the text file
Showmessage('Your password has been changed to '+''''+sPassword+'''');
if Length(sPassword) < 3 then
  begin
  Showmessage('Warning: Your password '''+sPassword+''' is less than 3 characters.');
  end;

end;

procedure TfrmMainPage.btnChargeUserClick(Sender: TObject);
var sarrCharge : Array[1..2] of String;
    sReason, sUser, sUserPath, sLine: String;
    curFee, curTotal : Currency;
    i : Integer;
begin
if lstUsers.ItemIndex = -1 then
  begin
  Showmessage('Select a user first');
  btnLoadUsers.SetFocus;
  Exit;
  end;

sarrCharge[1] := '';
sarrCharge[2] := '';
if InputQuery('Add Fee', ['Enter fee:', 'Enter reason:'], sarrCharge) then
  begin
    if TryStrToCurr(sarrCharge[1], curFee) then
    begin
      curFee := abs(curFee); //Ensures that you can't give negative fees (refunds);
      sReason := sarrCharge[2];
    end
  else
    begin
    Showmessage(sarrCharge[1]+' is invalid');
    Exit;
    end;
  end;

sUser := lstUsers.Items[lstUsers.ItemIndex];   //Stores the name you clicked on in sUser
sUserPath := ExtractFilePath(ParamStr(0))+'Users\'+sUser+'.txt';  //Stores the path of that user's text file in sUserPath

sLine := redUserInfo.Lines[redUserInfo.Lines.Count-1];
sLine := StringReplace(sLine,'R','',[rfReplaceAll]);       //Removes the R (rand symbol)
sLine := StringReplace(sLine, #160, '', [rfReplaceAll]);   //Removes non-breaking spaces (seperates thousands)
curTotal := StrToCurr(sLine);
curTotal := curTotal + curFee;

for i := 1 to 3 do
  redUserInfo.Lines.Delete(redUserInfo.Lines.Count -1);

redUserInfo.Paragraph.TabCount := 2;   //Sets tab count to 2         }
redUserInfo.Paragraph.Tab[0] := 75;    //Sets first tab position     } Tabstop formatting
redUserInfo.Paragraph.Tab[1] := 120;   //Sets second tab position    }

redUserInfo.Lines.Add(CurrToStrF(curFee,ffCurrency,2)+#9+'Fee'+#9+sReason);
redUserInfo.Lines.Add('------------------------------------');
redUserInfo.Lines.Add('Total:');
redUserInfo.Lines.Add(CurrToStrF(curTotal,ffCurrency,2));

redUserInfo.Lines.SaveToFile(sUserPath); //Saves the changes to the user's text file
end;

function TfrmMainPage.FlipBool(bInput: Boolean): Boolean;
begin                   //Turns a True boolean into a False boolean and vise versa
if bInput = False then
  result := True
else
  result := False ;
end;

procedure TfrmMainPage.FormClose(Sender: TObject; var Action: TCloseAction);
begin
if curOutStandingBalance > 0 then
  begin
  PlaySound('cha ching.wav', 0, SND_FILENAME or SND_ASYNC);  //Plays sound effect
  Showmessage('Your outstanding balance of '+CurrToStrF(curOutstandingBalance, ffcurrency, 2)+' has been charged to your card.');  //Shows how much money you spent in this session
  end;
frmLogin.Close;
end;

procedure TfrmMainPage.FormCreate(Sender: TObject);
var sFilePath : String;
begin
FormatSettings.DecimalSeparator := '.'; //Changes the decimal seperator to a . instead of a , (otherwise StrToFloat does not recognise 10.5 as a decimal number, but rather 10,5)

iBasicCalcStep := 1;                        //Sets the basic calculator's free uses
iFreePlusUses := 3;
iFreeMinusUses := 3;
iFreeMultiplyUses := 2;
iFreeDivideUses := 2;

redFreeClicksLeft.paragraph.tabCount := 1;
redFreeClicksLeft.Paragraph.Tab[0] := 50;   //This controls the position of the tab stop. If the tab stop is not placed far enough then the numbers will not be aligned
redCost.Paragraph.TabCount := 2; //
redCost.Paragraph.Tab[0] := 75;  // Formats tabstops
redCost.Paragraph.Tab[1] := 120; //
RefreshFreeUses;

curOutstandingBalance := 0;  //Outstanding balance is the amount you owe from this current instance of running Capitalistic Calculator. After you close the app, your outsanding balance is charged to your card and reset to 0. This is different from curTotalCost which is the total you have spent on Capitalistic Calculator as a whole.

bInvertedCalc := False ;

pgcMain.Pages[1].TabVisible := False ;     //Hides the Admin and settings tab by default on form create
pgcMain.Pages[2].TabVisible := False ;

edtAdminPassword.Text := sAdminPassword;

sFilePath := ExtractFilePath(ParamStr(0)) + 'costrates.txt' ;    //Grabs the root file path and adds costrates.txt "C:\...\Win32\Debug\costrates.txt"
if FileExists(sFilePath) = False then     //Checks if the file exists
  begin
  slCostRates := TStringList.Create;    //Creates a string list to store default cost values in
    try
    slCostRates.Add('0.01 PlusCost');        //Stores the default values into the String list
    slCostRates.Add('0.01 MinusCost');
    slCostRates.Add('0.05 MultiplyCost');
    slCostRates.Add('0.05 DivideCost');
    slCostRates.Add('0.10 PowersCost');
    slCostRates.Add('0.10 LogCost');
    slCostRates.Add('0.07 DivCost');
    slCostRates.Add('0.07 ModCost');
    slCostRates.Add('0.01 SinCost');
    slCostRates.Add('0.01 CosCost');
    slCostRates.Add('0.01 TanCost');
    slCostRates.Add('0.03 ConvertCost');
    slCostRates.SaveToFile('costrates.txt'); //Saves the values from the string list to a textfile
    finally
    slCostRates.Free;
    end;
  end;
lstCostRates.Items.LoadFromFile('costrates.txt'); //Loads the current cost rates into the listbox in settings
UpdateCostRates; //Stores costrates into variables

//Compatibility for smaller screens:
if Screen.WorkAreaRect.Height < 940 then
  begin
  frmMainPage.Height := Screen.WorkAreaRect.Height;
  scrbxForm.Height := frmMainPage.Height -10;
  end;
if Screen.WorkAreaWidth < 970 then
  begin
  frmMainPage.Width := Screen.WorkAreaRect.Width;
  scrbxForm.Width := frmMainPage.Width -10;
  end;

Randomize;
end;

procedure TfrmMainPage.FormResize(Sender: TObject);
begin
scrbxForm.Height := frmMainPage.Height -10;    //resizes the scrollbox with the form
scrbxForm.Width := frmMainPage.Width -10;
end;

procedure TfrmMainPage.FormShow(Sender: TObject);
var sLine : String;
begin
if sUserType = 'Basic' then
  begin

  end
else
  begin
  {This used to be in an UnlockAll procedure that I called from frmLogin and frmPaywall}
  bUnlocked := True;

  btnPlus.Enabled := True;
  btnMinus.Enabled := True;
  btnMultiply.Enabled := True;
  btnPlus.Enabled := True;

  pnlAdvancedCalculator.color := clGreen;
  edtTrig.Enabled := True;
  sedDiv1.Enabled := True;
  sedDiv2.Enabled := True;
  sedMod1.Enabled := True;
  sedMod2.Enabled := True;
  redAnswers.Enabled := True;
  redCost.Visible := True;
  edtBalance.Visible := True;

  chartInvest.Color := clLime ;

  frmMainPage.pgcMain.Pages[1].TabVisible := True ; //Shows the settings tab


  slUser := TStringList.Create;
  slUser.LoadFromFile(sPath);
  sUsername := slUser[0];   //Extracts first line from slUser and stores it in sUsername
  sPassword := sluser[1];   //Extracts second line from slUser and stores it in sPassword
  sUserType := slUser[2];   //Extracts third line from slUser and stores it in sUserType
  sLine := slUser[slUser.Count-1];  //Extracts the last line of slUser and stores it in sLine
  sLine := StringReplace(sLine,'R','',[rfReplaceAll]);       //Removes the R (rand symbol)
  sLine := StringReplace(sLine, #160, '', [rfReplaceAll]);   //Removes non-breaking spaces (seperates thousands)
  curTotalCost := StrToCurr(sLine);

  redCost.Lines.LoadFromFile(sPath);  //Loads the user's text file into redCost
  redCost.SelectAll;               //
  redCost.Paragraph.TabCount := 2; //
  redCost.Paragraph.Tab[0] := 75;  // Formats tabstops
  redCost.Paragraph.Tab[1] := 120; //

  if sUserType = 'Admin' then
    pgcMain.Pages[2].TabVisible := True; //Shows the admin tab
  end;

frmMainPage.btnBasicClearClick(frmMainPage.btnBasicClear);     //Disables the basic calculator plus, minus, multiply and divide buttons on startup
end;

procedure TfrmMainPage.Invest(rAmount : Double; bShowmessage : Boolean);
var rRate, rVolatility, rValue, rPreValue, rMaxValue : Double;  //I have to declare rAmount as a double otherwise TryStrToFloat doesn't work
    i, i2, iRange, iYears, iMaxIndex : Integer;
    arrValue : array of Currency ;
    sTotal, sWorth, sFutureYear, sRate, sMessage : String;
begin
if Length(edtGrowthRate.text) < 1 then         //Checks if edtGrowthRate is empty
  begin
  Showmessage('Please enter an interest rate.');
  Exit;
  end;

if not TryStrToFloat(edtGrowthRate.Text,rRate) then     //Tries to store the text in edtGrowthRate in a real variable
  begin
  Showmessage(edtGrowthRate.Text+' is not a valid number.');
  edtGrowthRate.SetFocus;
  Exit;
  end
else
  rRate := StrToFloat(edtGrowthRate.Text)/100;

if rRate > 1 then       //Sets a maximum growth rate
  begin
  rRate := 1;
  edtGrowthRate.Text := '100';
  end;

if rRate < -1 then   //Sets a maximum depreciation rate (min growth rate)
  begin
  rRate := -1;
  edtGrowthRate.Text := '-100';
  end;

iYears := sedYears.Value;
SetLength(arrValue,iYears+1);    //Sets the length of the array to the amount of years. arrValue : array[0..25] of Double. +1 to include year 0
iRange := sedVolatility.value ;
rPreValue := rAmount ;
rMaxValue := 0;

lblCrashed.Caption := '';
arrValue[0] := rAmount ;         // Same as in procedure TfrmMainPage.btnInvestClick
for i := 1 to iYears do              //  but using rAmount instead of rTotalCost
  begin
  rVolatility := RandomRange(-1*iRange,iRange+1)/100 ;    // Generates a random number with the Volatility Spin Edit input as a range and offsets the exponential curve with that number to add realism.
  rValue :=  RoundTo( rPreValue * (1 + rRate + rVolatility), -2 ) ; //Calculates the values for the exponential curve
                                                                                   //Volatility set to 0 gives you a clean exponential curve
    //Checks:
  if rValue > rMaxValue then //Checks to see if a new highest number was reached
    begin
    rMaxValue := rValue;      //Stores the value of the new highest number
    iMaxIndex := i;           //Stores the index (where on the chart is will be)
    end;
  if (rValue >= iHuge) or (rValue <= iTiny) then   // iHuge is close to the largest number that delphi can handle. It's a constant defined in GlobalVariables_u and its value is 922 trillion
    begin                                          //     and iTiny is the smallest. This prevents Delphi from looping back over into the negatives if the number gets too big
    rValue := iHuge;
    end;
  if rValue <= 0 then  //Checks if the stock crashed (reached a value of 0). This can happen at high volatility
    begin
    rValue := 0; //Prevents stock from having negative value
    lblCrashed.Caption := 'Your stocks crashed :('; //If your investment's value reaches 0 it stays at 0.
    end;

  arrValue[i] :=  rValue;   //Stores the exponential curve in an array
  rPreValue := rValue;  //Prepares prevalue for the next itiration of the loop. This loop
  end;

chartInvest.Series[0].Marks.DrawEvery := iYears ; //Makes the chart add a mark for the first and last value
chartInvest.Series[0].Clear;            //Clears the series before inputting the new one
for i := 0 to iYears do
  begin
  chartInvest.Series[0].AddXY(i,arrValue[i],'',clTeeColor) ;     //Draws the array onto the chart
  end;

if bShowmessage then
  begin
  sTotal := CurrToStrF(curTotalCost,ffcurrency,2) ;
  if arrValue[iYears] >= iHuge then
    sWorth := 'A LOT'
  else
    sWorth := CurrToStrF(arrValue[iYears],ffcurrency,2) ;
  sFutureYear := IntToStr(CurrentYear + iYears) ;
  sRate := edtGrowthRate.text ;
  sMessage := 'Your total of '+sTotal+' would be worth '+sWorth+' in '+sFutureYear+' if you invested it at an interest rate of '+sRate+'% instead of spending it on this calculator.' ;
  Showmessage(sMessage) ;
  end;

end;

procedure TfrmMainPage.LockFeatures;
begin
if bUnlocked = False then
  Begin
  if iFreePlusUses < 1 then
    btnPlus.Enabled := False;

  if iFreeMinusUses < 1 then
    btnMinus.Enabled := False;

  if iFreeMultiplyUses < 1 then
    btnMultiply.Enabled := False;

  if iFreeDivideUses < 1 then
    btnDivide.Enabled := False;
  end;
end;

procedure TfrmMainPage.lstUsersClick(Sender: TObject);
var sUser, sUserPath : String;
begin
sUser := lstUsers.Items[lstUsers.ItemIndex];   //Stores the name you clicked on in sUser
sUserPath := ExtractFilePath(ParamStr(0))+'Users\'+sUser+'.txt';  //Stores the path of that user's text file in sUserPath
redUserInfo.Lines.LoadFromFile(sUserPath); //Loads the selected user's text file to redUserInfo
redUserInfo.SelectAll;               //
redUserInfo.Paragraph.TabCount := 2; //
redUserInfo.Paragraph.Tab[0] := 75;  // Formats tabstops
redUserInfo.Paragraph.Tab[1] := 120; //
end;

procedure TfrmMainPage.RefreshFreeUses;
begin
if iFreePlusUses < 0 then
  begin
  iFreePlusUses := 0 ;
  end;
if iFreeMinusUses < 0 then
  begin
  iFreeMinusUses := 0 ;
  end;
if iFreeMultiplyUses < 0 then
  begin
  iFreeMultiplyUses := 0 ;
  end;
if iFreeDivideUses < 0 then
  begin
  iFreeDivideUses := 0 ;
  end;

redFreeClicksLeft.clear;
redFreeClicksLeft.lines.add('Remaining free button uses:'+#13+    //Displays the current free uses
                            #13+
                            'Plus +'+#9+IntToStr(iFreePlusUses)+#13+
                            'Minus -'+#9+IntToStr(iFreeMinusUses)+#13+
                            'Multiply x'+#9+IntToStr(iFreeMultiplyUses)+#13+
                            'Divide /'+#9+IntToStr(iFreeDivideUses));

redFreeClicksLeft.Perform(EM_SCROLL, SB_TOP, 0); //Scrolls to the top of the edit
end;

procedure TfrmMainPage.rgpBackgroundColourClick(Sender: TObject);
var iColor : Integer ;
begin
tmrRainbowBackground.Enabled := False ;  //Turns the rainbow timer off

case rgpBackgroundColour.ItemIndex of
0 : iColor := clWhite ;
1 : iColor := clBlack ;
2 : iColor := clRed ;
3 : iColor := clGreen ;
4 : iColor := clBlue ;
5 : begin
    iColor := clBlack ;
    tmrRainbowBackground.Enabled := True ;
    end;
end;

shpBackgroundColor.Brush.Color := iColor ;
shpCalculatorBackground.Brush.Color := iColor ;
end;

procedure TfrmMainPage.shpWatermarkContextPopup(Sender: TObject; MousePos: TPoint;
  var Handled: Boolean);
begin
ShellExecute(0, 'open', 'https://github.com/RichardT-ZA/IT-PAT-2025', nil, nil, SW_SHOWNORMAL);  //Links to my github where this project is uploaded
end;

function TfrmMainPage.Subscript(iInput: Integer): String;    //Function that changes regular numbers into subscript
var i : Integer;
    sInput : String;
    cChar : Char;
begin
sInput := IntToStr(iInput);     //Converts the integer input to a string
result := '';          //Initialises the output to an empty string

for i := 1 to Length(sInput) do      //Loops through the whole number and checks each character
  begin
    case sInput[i] of
    '0' : cChar := '₀';     //Converts the character to its subscript variation
    '1' : cChar := '₁';
    '2' : cChar := '₂';
    '3' : cChar := '₃';
    '4' : cChar := '₄';
    '5' : cChar := '₅';
    '6' : cChar := '₆';
    '7' : cChar := '₇';
    '8' : cChar := '₈';
    '9' : cChar := '₉';
    end;
  result := result + cChar ;    //Concatenates the output string
  end;

end;

procedure TfrmMainPage.tmrAdvertisePremiumTimer(Sender: TObject);
var iDlgResponse : Integer ;
begin
if iDelayInSeconds < 1 then
  begin
  tmrAdvertisePremium.Enabled := False ;
  iDlgResponse := MessageDlg('Consider accessing premium features.'+#13#10+'You can register for a premium account FOR FREE'+#13#10+'Sign up?',mtInformation,mbYesNo,0);
  if iDlgResponse = mrYes then
    begin
    frmPaywall.ShowModal;     //Shows the paywall form
    end;
  end;

iDelayInSeconds := iDelayInSeconds -1;
end;

procedure TfrmMainPage.tmrRainbowBackgroundTimer(Sender: TObject);
var iRandom, iColor : Integer ;
begin
iRandom := Random(5)+1 ;  //Generates a random number from 1 to 5

case iRandom of
1 : iColor := clWhite ;     //Picks a color using the randomly generated number
2 : iColor := clBlack ;
3 : iColor := clRed ;
4 : iColor := clGreen ;
5 : iColor := clBlue ;
end;

shpBackgroundColor.Brush.Color := iColor ;       //Changes the color of the square in settings
shpCalculatorBackground.Brush.Color := iColor ; //Changes the background color of the calculator form
end;

procedure TfrmMainPage.tmrTurnDataCollectionBackOnTimer(Sender: TObject);
begin
tsCollectData.State := tssOn ;    //Turns the toggle switch back on
tmrTurnDataCollectionBackOn.Enabled := False ;     //turns the timer off
tmrTurnDataCollectionBackOn.Interval := RandomRange(0,3000);    //Changes the delay before switching to make it more random
end;

procedure TfrmMainPage.tsCollectDataClick(Sender: TObject);
begin
if tsCollectData.State = tssOff then            //Checks if the toggle was turned off
  tmrTurnDataCollectionBackOn.Enabled := True ;    //If off, turn on the timer that turns it on again in 2 seconds
end;

end.
